#!/usr/bin/env bash
# php2shell_hunt_linux.sh v2.1 - read-only compromise triage for PHP2Shell
# (CVE-2026-109618 / CVE-2026-109619). Collects and preserves evidence, flags indicators.
# Changes nothing on the host apart from writing to the output directory.
#
# Usage: sudo ./php2shell_hunt_linux.sh [options]
#   -s SINCE    start of hunt window, anything `date -d` parses, read as UTC
#               (default 2026-10-17 = earliest exploitation attempt reported, Amazon MadPot)
#   -w WEBROOT  web root to scan (repeatable). Default: /var/www /srv /usr/share/nginx
#               /home/*/public_html /home/*/www /opt/bitnami
#   -o OUTDIR   output directory; must not exist yet and must not be inside a web root
#               (default /var/tmp/php2shell_<host>_<utc timestamp>). Prefer external/mounted storage.
#   -c CASE     case / ticket reference recorded in the chain-of-custody record
#   -a ANALYST  analyst name (default: the invoking sudo user)
#   -L MB       cap on raw log copies in MB (default 2048; 0 = hash-list logs only, copy none)
#   -F MB       max size of any other single preserved file in MB (default 50)
#   -m N        OPT-IN: core-dump up to N PHP/web worker processes with gcore (pauses each briefly)
#   -r DIR      drop this host's one-line result (<name>.summary.json/.csv) into DIR (mounted share) for roll-up
#   -E          with -r: also copy the evidence .tgz + .sha256 to DIR and verify the hash
#   -h          help
#
# Verdict (top of findings.txt and printed at the end):
#   COMPROMISE SUSPECTED (exit 5) > ACTION REQUIRED (exit 4) > REVIEW (exit 3) > CLEAN / NOT EXPOSED (exit 0)
# Severity: CRITICAL = signs of compromise; HIGH = vulnerable and serving, or exploitation attempts;
#           REVIEW = analyst look, often benign; INFO = context only, never counted.
# Generic host checks only count (REVIEW) when PHP is actually serving web requests on the host.
#
# Run BEFORE restarting PHP-FPM / Apache: a restart wipes worker memory and the live
# process state you need for scoping.
# Output: OUTDIR/{findings.txt, chain_of_custody.txt, collection.log, SHA256SUMS, evidence/}
#         plus OUTDIR.tgz and OUTDIR.tgz.sha256. All timestamps written by this script are UTC.

if [ -z "${BASH_VERSINFO[0]:-}" ] || [ "${BASH_VERSINFO[0]}" -lt 4 ] ||
   { [ "${BASH_VERSINFO[0]}" -eq 4 ] && [ "${BASH_VERSINFO[1]}" -lt 2 ]; }; then
  echo "bash 4.2+ required" >&2; exit 2
fi
shopt -s nullglob lastpipe
umask 077
VERSION="2.1"

SINCE="2026-10-17"; WEBROOTS=(); OUT=""; CASE_ID="unassigned"; ANALYST="${SUDO_USER:-$(id -un)}"
LOGCAP_MB=2048; FILECAP_MB=50; DUMPS=0; RESULT_DIR=""; COPY_EV=0
usage(){ sed -n '2,33p' "$0"; }
die(){ echo "ERROR: $*" >&2; exit 1; }
isnum(){ [[ "$1" =~ ^[0-9]+$ ]]; }
while getopts "s:w:o:c:a:L:F:m:r:Eh" opt; do
  case "$opt" in
    s) SINCE="$OPTARG" ;;
    w) WEBROOTS+=("$OPTARG") ;;
    o) OUT="$OPTARG" ;;
    c) CASE_ID="$OPTARG" ;;
    a) ANALYST="$OPTARG" ;;
    L) isnum "$OPTARG" || die "-L needs a number"; LOGCAP_MB="$OPTARG" ;;
    F) isnum "$OPTARG" || die "-F needs a number"; FILECAP_MB="$OPTARG" ;;
    m) isnum "$OPTARG" || die "-m needs a number"; DUMPS="$OPTARG" ;;
    r) RESULT_DIR="$OPTARG" ;;
    E) COPY_EV=1 ;;
    h) usage; exit 0 ;;
    *) usage >&2; exit 2 ;;
  esac
done

# Capture host time zone, then work in UTC so every timestamp we write is unambiguous.
HOST_TZ="$(date +'%Z (UTC%:z)') $(readlink /etc/localtime 2>/dev/null | sed 's|.*zoneinfo/||')"
START_LOCAL="$(date '+%F %T %Z')"
export TZ=UTC LC_ALL=C
START_UTC="$(date -u +%FT%TZ)"
TS="$(date -u +%Y%m%dT%H%M%SZ)"
SINCE_NORM="$(date -d "$SINCE" '+%F %T' 2>/dev/null)" || die "cannot parse -s '$SINCE'"

[ ${#WEBROOTS[@]} -eq 0 ] && WEBROOTS=(/var/www /srv /usr/share/nginx /home/*/public_html /home/*/www /opt/bitnami)
_r=(); for d in "${WEBROOTS[@]}"; do [ -d "$d" ] && _r+=("$(readlink -f "$d")"); done
WEBROOTS=(); while IFS= read -r d; do [ -n "$d" ] && WEBROOTS+=("$d"); done < <(printf '%s\n' "${_r[@]}" | sort -u)

HOST="$(hostname -s 2>/dev/null || hostname)"
OUT="${OUT:-/var/tmp/php2shell_${HOST}_${TS}}"
[ -e "$OUT" ] && die "output directory $OUT already exists - refusing to mix collections"
mkdir -p "$(dirname "$OUT")" && mkdir -m 700 "$OUT" || die "cannot create $OUT"
OUT="$(cd "$OUT" && pwd -P)"
for d in "${WEBROOTS[@]}"; do
  case "$OUT/" in "$d"/*) rmdir "$OUT"; die "output $OUT is inside web root $d - evidence would be web-reachable; use -o" ;; esac
done

EV="$OUT/evidence"; TMPD="$OUT/.tmp"
mkdir -p "$EV/files" "$EV/proc" "$EV/memory" "$EV/system" "$TMPD" || die "cannot create evidence tree"
F="$OUT/findings.txt"; LOG="$OUT/collection.log"; COLL="$EV/collected_files.tsv"
REF="$TMPD/since_ref"
touch -d "$SINCE_NORM" "$REF" || die "cannot create time reference"
printf 'collected_utc\tcategory\tsha256_original\tsha256_copy\tsize\tmtime_utc\tctime_utc\towner:group\tmode\toriginal_path\tstored_as\n' >"$COLL"
[ "$(id -u)" -eq 0 ] || echo "WARN: not root - results will be incomplete" >&2

log(){ printf '%s  %s\n' "$(date -u +%FT%TZ)" "$*" >>"$LOG"; }
log "php2shell_hunt_linux.sh v$VERSION started by $(id -un) (uid $(id -u)) analyst='$ANALYST' case='$CASE_ID'"
log "command: $0 $*"
log "output: $OUT   free space: $(df -Pk "$OUT" | awk 'NR==2{printf "%.1f GB", $4/1048576}')"

# Published source IPs (Amazon MadPot, VulnCheck). Shared anonymizer infra: investigate, don't auto-block.
IOC_IPS="$EV/ioc_ips.txt"
cat >"$IOC_IPS" <<'EOF'
103.216.220.92
31.223.184.166
37.19.200.5
134.209.159.64
103.114.163.188
95.217.98.37
85.11.167.243
45.198.224.169
109.71.252.97
EOF
IOC_ARGS=(); while read -r ip; do IOC_ARGS+=(-e "$ip"); done <"$IOC_IPS"

WEBPROC_RE='^(php|php[0-9.]+|php-fpm.*|php-cgi.*|lsphp.*|apache2|httpd|nginx|frankenphp|litespeed|lshttpd|caddy|lighttpd|hhvm)$'
TOOL_RE='^(sh|bash|dash|zsh|ksh|ash|csh|tcsh|fish|busybox|python[0-9.]*|perl|ruby|lua|nc|ncat|netcat|socat|curl|wget|base64|openssl|xxd|telnet|id|whoami|uname|hostname|ifconfig|ip|nohup|setsid|mkfifo|crontab|ssh|scp|chmod)$'
SHELL_RE='(eval|assert|create_function)[[:space:]]*\(|base64_decode[[:space:]]*\(|gz(inflate|uncompress|decode)[[:space:]]*\(|str_rot13[[:space:]]*\(|(shell_exec|passthru|system|proc_open|popen|pcntl_exec)[[:space:]]*\(|(^|[^_a-zA-Z>])exec[[:space:]]*\(|fsockopen[[:space:]]*\(|\$_(POST|GET|REQUEST|COOKIE)[[:space:]]*\['
PHPEXT_FIND=( \( -iname '*.php' -o -iname '*.php[0-9]' -o -iname '*.phtml' -o -iname '*.phar' -o -iname '*.pht' -o -iname '*.phps' -o -iname '*.inc' \) )

R_SEV=(); R_LABEL=(); R_SLUG=(); R_N=(); R_ACT=(); R_S1=(); R_S2=()
PHP_SERVING=0
section(){ printf '\n=== %s ===\n' "$*" >>"$F"; echo ">> $*" >&2; log "section: $*"; }
note(){ printf '    %s\n' "$*" >>"$F"; }
# flag SEVERITY LABEL SLUG [ACTION] : reads stdin; records a finding if non-empty (runs in this shell via lastpipe).
# SEVERITY: CRITICAL | HIGH | REVIEW | INFO, or e.g. "REVIEW>=20" = REVIEW only if >= 20 lines, otherwise INFO.
THR_RE='^([A-Z]+)>=([0-9]+)$'
flag(){
  local sev="$1" label="$2" slug="$3" action="${4:-}" tmp n
  tmp="$(mktemp "$TMPD/flag.XXXXXX")"; cat >"$tmp"
  if [ -s "$tmp" ]; then
    n=$(wc -l <"$tmp")
    if [[ "$sev" =~ $THR_RE ]]; then sev="${BASH_REMATCH[1]}"; [ "$n" -ge "${BASH_REMATCH[2]}" ] || sev=INFO; fi
    printf '[%-8s] %s  (%s lines -> evidence/%s.txt)\n' "$sev" "$label" "$n" "$slug" >>"$F"
    [ -n "$action" ] && printf '           ACTION: %s\n' "$action" >>"$F"
    head -n 20 "$tmp" | cut -c1-300 | sed 's/^/           /' >>"$F"
    R_SEV+=("$sev"); R_LABEL+=("$label"); R_SLUG+=("$slug"); R_N+=("$n"); R_ACT+=("$action")
    R_S1+=("$(sed -n 1p "$tmp" | tr -cd '[:print:]' | cut -c1-170)"); R_S2+=("$(sed -n 2p "$tmp" | tr -cd '[:print:]' | cut -c1-170)")
    mv "$tmp" "$EV/$slug.txt"
    log "FLAG $slug [$sev]: $n lines"
  else
    printf '[   ok   ] %s\n' "$label" >>"$F"
    rm -f "$tmp"
  fi
}
# Generic host checks only count where PHP is actually serving web requests; elsewhere they are context only.
gsev(){ if [ "$PHP_SERVING" -eq 1 ]; then echo REVIEW; else echo INFO; fi; }
sha(){ sha256sum -- "$1" 2>/dev/null | cut -d' ' -f1; }
declare -A PRESERVED=()
COPIED_LOG_BYTES=0
# preserve CATEGORY [cap_bytes] : reads file paths on stdin, copies each (metadata kept) to
# evidence/files/CATEGORY/<original path> and records hashes + metadata in collected_files.tsv
preserve(){
  local cat="$1" cap="${2:-$((FILECAP_MB*1048576))}" src dst h1 h2 sz meta stored
  while IFS= read -r src; do
    [ -n "$src" ] && [ -f "$src" ] || continue
    [ -n "${PRESERVED[$cat|$src]:-}" ] && continue
    PRESERVED[$cat|$src]=1
    sz=$(stat -L -c %s -- "$src" 2>/dev/null) || continue
    meta=$(stat -L -c '%y'$'\t''%z'$'\t''%U:%G'$'\t''%A' -- "$src" 2>/dev/null | sed -E 's/\.[0-9]+ \+0000/Z/g')
    if [ "$cat" = logs ]; then
      if [ "$LOGCAP_MB" -eq 0 ] || [ $((COPIED_LOG_BYTES+sz)) -gt $((LOGCAP_MB*1048576)) ]; then
        printf '%s\t%s\t%s\t-\t%s\t%s\t%s\t%s\n' "$(date -u +%FT%TZ)" "$cat" "$(sha "$src")" "$sz" "$meta" "$src" "NOT COPIED (log cap ${LOGCAP_MB} MB) - hashed in place" >>"$COLL"
        continue
      fi
    elif [ "$sz" -gt "$cap" ]; then
      printf '%s\t%s\t%s\t-\t%s\t%s\t%s\t%s\n' "$(date -u +%FT%TZ)" "$cat" "$(sha "$src")" "$sz" "$meta" "$src" "NOT COPIED (over size cap)" >>"$COLL"
      continue
    fi
    dst="$EV/files/$cat/${src#/}"
    mkdir -p "$(dirname "$dst")"
    h1=$(sha "$src")
    if cp -pL -- "$src" "$dst" 2>/dev/null; then
      h2=$(sha "$dst"); stored="evidence/files/$cat/${src#/}"
      [ "$h1" != "$h2" ] && stored="$stored (source changed during copy - live file)"
      [ "$cat" = logs ] && COPIED_LOG_BYTES=$((COPIED_LOG_BYTES+sz))
    else
      h2="-"; stored="COPY FAILED"
    fi
    [ -L "$src" ] && stored="$stored [symlink -> $(readlink "$src")]"
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$(date -u +%FT%TZ)" "$cat" "$h1" "$h2" "$sz" "$meta" "$src" "$stored" >>"$COLL"
  done
}
# capture_proc PID REASON : preserve /proc state and the executable image of a live process
capture_proc(){
  local pid="$1" why="$2" d="$EV/proc/$1" sz
  [ -d "/proc/$pid" ] || return
  [ -d "$d" ] && { echo "$why" >>"$d/reason.txt"; return; }
  mkdir -p "$d"; echo "$why" >"$d/reason.txt"
  tr '\0' ' ' <"/proc/$pid/cmdline" >"$d/cmdline.txt" 2>/dev/null
  tr '\0' '\n' <"/proc/$pid/environ" >"$d/environ.txt" 2>/dev/null
  cp "/proc/$pid/status" "$d/status.txt" 2>/dev/null
  cp "/proc/$pid/maps" "$d/maps.txt" 2>/dev/null
  { echo "exe: $(readlink "/proc/$pid/exe")"; echo "cwd: $(readlink "/proc/$pid/cwd")"; echo "root: $(readlink "/proc/$pid/root")"; } >"$d/links.txt" 2>/dev/null
  ls -l "/proc/$pid/fd/" >"$d/fd.txt" 2>/dev/null
  sz=$(stat -L -c %s "/proc/$pid/exe" 2>/dev/null || echo 0)
  if [ "$sz" -gt 0 ] && [ "$sz" -le $((FILECAP_MB*1048576)) ]; then
    cp "/proc/$pid/exe" "$d/exe.bin" 2>/dev/null && chmod 400 "$d/exe.bin" && echo "sha256 exe.bin: $(sha "$d/exe.bin")" >>"$d/links.txt"
  fi
  log "captured /proc/$pid ($why)"
}

# Web users: well-known names + whoever runs PHP/web workers (covers per-site FPM pools)
WEBUSERS=()
for u in www-data apache nginx httpd lighttpd wwwrun http litespeed caddy nobody; do
  id -u "$u" >/dev/null 2>&1 && WEBUSERS+=("$u")
done
while read -r u; do
  case " ${WEBUSERS[*]} " in *" $u "*) ;; *) id -u "$u" >/dev/null 2>&1 && WEBUSERS+=("$u") ;; esac
done < <(ps -eo user:32=,comm= 2>/dev/null | awk -v re="$WEBPROC_RE" '$2 ~ re && $1 != "root" {print $1}' | sort -u)
WEBUSER_RE="^($(IFS='|'; echo "${WEBUSERS[*]:-__none__}"))\$"
WEBUIDS=(); for u in "${WEBUSERS[@]}"; do WEBUIDS+=("$(id -u "$u")"); done
WEBUID_RE="$(IFS='|'; echo "${WEBUIDS[*]}")"
HOMES=(); for u in "${WEBUSERS[@]}"; do h=$(getent passwd "$u" | cut -d: -f6); [ -n "$h" ] && [ "$h" != "/" ] && [ -d "$h" ] && HOMES+=("$h"); done

{
  echo "PHP2Shell hunt (CVE-2026-109618 / CVE-2026-109619) - $HOST   [script v$VERSION]"
  echo "Case: $CASE_ID   Analyst: $ANALYST"
  echo "Run: $START_UTC (UTC)   host local: $START_LOCAL   Window since: $SINCE_NORM UTC   Kernel: $(uname -r)"
  echo "Web users: ${WEBUSERS[*]:-none found}"
  echo "Web roots: ${WEBROOTS[*]:-none found (use -w)}"
  echo "Severity: CRITICAL = signs of compromise | HIGH = vulnerable and serving, or exploitation attempts | REVIEW = analyst look, often benign | INFO = context, not counted | ok = nothing found"
  echo "All times written by this script are UTC. Raw log lines keep the host's own time zone: $HOST_TZ"
} >"$F"

# --------------------------------------------------------------------------
section "0. Volatile snapshot (evidence/ only)"
ps -eo pid,ppid,user:32,lstart,etime,args --forest >"$EV/ps_forest.txt" 2>&1
ps -eo pid=,ppid=,user:32=,comm=,args= >"$EV/ps_raw.txt" 2>/dev/null
ss -tanpe >"$EV/ss_tcp.txt" 2>&1 || netstat -tanpe >"$EV/ss_tcp.txt" 2>&1
ss -uanpe >"$EV/ss_udp.txt" 2>&1
ss -xanp >"$EV/ss_unix.txt" 2>&1
cat /proc/locks >"$EV/proc_locks.txt" 2>/dev/null
{ uname -a; echo; uptime; echo; cat /etc/os-release 2>/dev/null; } >"$EV/system/os.txt" 2>&1
{ who -a; echo; last -Fwn 100 2>/dev/null; } >"$EV/system/logins.txt" 2>&1
{ ip addr; echo; ip route; echo; ip neigh; echo; cat /etc/resolv.conf /etc/hosts; } >"$EV/system/network_config.txt" 2>&1
{ lsmod; echo; mount; echo; df -h; } >"$EV/system/modules_mounts.txt" 2>&1
command -v lsof >/dev/null 2>&1 && lsof -nP -i >"$EV/system/lsof_inet.txt" 2>&1
{ command -v dpkg-query >/dev/null 2>&1 && dpkg-query -W -f='${Package}\t${Version}\t${Status}\n' '*php*' 2>/dev/null
  command -v rpm >/dev/null 2>&1 && rpm -qa --qf '%{NAME}\t%{VERSION}-%{RELEASE}\t%{INSTALLTIME:date}\n' 2>/dev/null | grep -i php
} | sort >"$EV/system/php_packages.txt"
note "process tree, sockets, /proc/locks, logins, network config, packages saved."
if [ "$DUMPS" -gt 0 ]; then
  if command -v gcore >/dev/null 2>&1; then
    n=0
    for pid in $(awk -v re="$WEBPROC_RE" '$4 ~ re && $3 != "root" {print $1}' "$EV/ps_raw.txt"); do
      [ "$n" -ge "$DUMPS" ] && break
      gcore -o "$EV/memory/core" "$pid" >>"$LOG" 2>&1 && n=$((n+1)) && log "gcore pid $pid"
    done
    note "memory: $n worker core dump(s) in evidence/memory/ (gcore). Treat as highly sensitive (credentials, session data)."
  else
    note "memory: -m requested but gcore (gdb) not installed - use AVML/LiME BEFORE any restart."
  fi
else
  note "memory: not captured. Use -m N (gcore), or AVML/LiME, on php-fpm/apache2 workers BEFORE any restart."
fi

# --------------------------------------------------------------------------
section "1. PHP runtimes (what is actually serving requests)"
verdict(){
  local maj min pat fix
  IFS=. read -r maj min pat <<<"$1"
  case "$maj.$min" in
    8.2) fix=35 ;; 8.3) fix=36 ;; 8.4) fix=27 ;; 8.5) fix=12 ;;
    *) echo "EOL branch: no upstream fix - vendor backport (CloudLinux/ea-php/LTS) or isolate"; return ;;
  esac
  if [ "${pat:-0}" -ge "$fix" ]; then echo "patched upstream"
  else echo "below $maj.$min.$fix - VULNERABLE unless distro backport (see backport_check)"; fi
}
# Only execute a binary to ask its version if it is root-owned, not group/world-writable and in a system path.
trusted_exec(){
  [[ "$1" =~ ^/(usr|opt|bin|sbin)/ ]] && [[ ! "$1" =~ /(tmp|shm)/ ]] || return 1
  [ "$(stat -c %u -- "$1" 2>/dev/null)" = 0 ] || return 1
  [ -z "$(find "$1" -maxdepth 0 -perm /022 2>/dev/null)" ]
}
# Read the version string compiled into the binary/module (never runs it unless trusted).
php_version(){
  local v
  v=$(grep -aoE -m1 'X-Powered-By: PHP/[0-9]+\.[0-9]+\.[0-9]+' -- "$1" 2>/dev/null | head -n1 | sed 's|.*PHP/||')
  if [ -z "$v" ] && [ -n "${2:-}" ] && trusted_exec "$2"; then
    v=$("$2" -n -v </dev/null 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -n1)
  fi
  echo "$v"
}
declare -A SEEN_EXE=()
for pid in $(awk -v re="$WEBPROC_RE" '$4 ~ re {print $1}' "$EV/ps_raw.txt"); do
  exe=$(readlink "/proc/$pid/exe" 2>/dev/null) || continue
  mods=$(grep -oE '/[^ ]*(libphp|mod_php)[^ ]*\.so( \(deleted\))?' "/proc/$pid/maps" 2>/dev/null | sort -u | tr '\n' ' ')
  key="$exe|$mods"
  if [ -z "${SEEN_EXE[$key]:-}" ]; then
    v=$(php_version "/proc/$pid/exe")       # reads the image actually running, even if deleted on disk
    SEEN_EXE[$key]="${v:--}"
  fi
  printf '%s\tversion=%s\t%s\n' "$exe" "${SEEN_EXE[$key]}" "$mods"
done | sort | uniq -c >"$EV/running_runtimes.txt"
# Exposure: PHP actually answering web requests = FPM/CGI/LSAPI/FrankenPHP workers, or a web server with libphp loaded
if grep -qE 'libphp|mod_php' "$EV/running_runtimes.txt" ||
   awk '{print $4}' "$EV/ps_raw.txt" | grep -qE '^(php-fpm.*|php-cgi.*|lsphp.*|frankenphp|hhvm)$' ||
   grep -qE ' php[0-9.]* .*(-S [^ ]+:[0-9]+|artisan serve)' "$EV/ps_raw.txt"; then
  PHP_SERVING=1
fi
grep -F '(deleted)' "$EV/running_runtimes.txt" | grep -E 'php|lsphp|frankenphp' |
  flag HIGH "PHP workers still running a replaced (deleted) binary or module - old code in memory" stale_runtimes \
    "Patched on disk but the old (likely vulnerable) build is still running. Restart PHP-FPM/Apache after evidence is copied off."

{
  for b in /usr/bin/php* /usr/sbin/php-fpm* /usr/local/bin/php* /usr/local/sbin/php-fpm* \
           /opt/cpanel/ea-php*/root/usr/bin/php /opt/cpanel/ea-php*/root/usr/sbin/php-fpm \
           /opt/alt/php*/usr/bin/php /opt/alt/php*/usr/sbin/php-fpm /opt/remi/php*/root/usr/bin/php \
           /opt/remi/php*/root/usr/sbin/php-fpm /opt/plesk/php/*/bin/php /opt/plesk/php/*/sbin/php-fpm \
           /usr/local/lsws/lsphp*/bin/lsphp \
           /usr/lib/apache2/modules/libphp*.so /usr/lib64/httpd/modules/libphp*.so /usr/lib/httpd/modules/libphp*.so \
           /usr/local/apache2/modules/libphp*.so /opt/bitnami/*/modules/libphp*.so \
           $(awk '{print $2}' "$EV/running_runtimes.txt") \
           $(grep -oE '/[^ ]*(libphp|mod_php)[^ ]*\.so' "$EV/running_runtimes.txt"); do
    [ -f "$b" ] || continue
    case "$(basename "$b")" in php-config*|phpize*|phpdbg*|apache2|httpd|nginx|caddy|litespeed|lshttpd|lighttpd) continue ;; esac
    case "$b" in *.so) v=$(php_version "$b") ;; *) v=$(php_version "$b" "$b") ;; esac
    [ -n "$v" ] && printf '%-60s %-8s %s\n' "$(readlink -f "$b")" "$v" "$(verdict "$v")"
  done
  awk -F'\t' '$2 ~ /version=[0-9]/ {sub(/^ *[0-9]+ /,"",$1); v=$2; sub(/version=/,"",v); print $1 "\t" v}' "$EV/running_runtimes.txt" |
    while IFS=$'\t' read -r e v; do printf '%-60s %-8s %s\n' "RUNNING: $e" "$v" "$(verdict "$v")"; done
} | sort -u >"$EV/php_versions.txt"
note "$(wc -l <"$EV/php_versions.txt") PHP binaries/modules found (evidence/php_versions.txt; RUNNING = version read from the live process image)"
{
  for f in /usr/share/doc/php*/changelog.Debian.gz; do
    zgrep -qE 'CVE-2026-10961[89]' "$f" 2>/dev/null && echo "fix in changelog: $f"
  done
  if command -v rpm >/dev/null 2>&1; then
    for p in $(rpm -qa 2>/dev/null | grep -i php | grep -E -- '-(common|cli|fpm)-'); do
      rpm -q --changelog "$p" 2>/dev/null | grep -qE 'CVE-2026-10961[89]' && echo "fix in changelog: $p"
    done
  fi
} >"$EV/backport_check.txt"
note "distro packages whose changelog names the CVEs: $(wc -l <"$EV/backport_check.txt") (evidence/backport_check.txt)"
# Which vulnerable builds are serving? Prefer the version read from the running image; fall back to installed builds.
grep -E '^RUNNING: .*(VULNERABLE|EOL)' "$EV/php_versions.txt" >"$TMPD/vuln_serving"
if [ "$PHP_SERVING" -eq 1 ] && ! grep -q '^RUNNING: ' "$EV/php_versions.txt"; then
  grep -vE '^RUNNING: ' "$EV/php_versions.txt" | grep -E 'VULNERABLE|EOL' >>"$TMPD/vuln_serving"   # running version unreadable
  grep -vE '^RUNNING: ' "$EV/php_versions.txt" | grep -vE 'VULNERABLE|EOL' >"$TMPD/vuln_idle_none"
  : >"$TMPD/vuln_idle"
else
  grep -vE '^RUNNING: ' "$EV/php_versions.txt" | grep -E 'VULNERABLE|EOL' >"$TMPD/vuln_idle"
fi
if [ -s "$EV/backport_check.txt" ]; then
  VSEV=REVIEW; VACT="Upstream version is below the fix BUT the distro changelog lists the CVE fix (backport_check.txt). Confirm the installed package release includes it; if yes this is patched."
else
  VSEV=HIGH;   VACT="Client-reportable: exposed to PHP2Shell. Patch to a fixed release (or distro update) or isolate. Restart PHP-FPM/Apache only after evidence is copied off."
fi
[ "$PHP_SERVING" -eq 1 ] || { [ "$VSEV" = HIGH ] && VSEV=REVIEW; }   # running-image version but nothing serving (e.g. CLI worker)
flag "$VSEV" "Vulnerable PHP is serving web requests (below 8.2.35 / 8.3.36 / 8.4.27 / 8.5.12, or EOL branch)" php_vulnerable_serving "$VACT" <"$TMPD/vuln_serving"
flag "$(gsev)" "Vulnerable PHP installed but not the build serving web requests" php_vulnerable_idle \
  "Not reachable by PHP2Shell unless wired into a web server/FPM pool. Update or remove at the next maintenance window." <"$TMPD/vuln_idle"
for rt in docker podman; do
  command -v "$rt" >/dev/null 2>&1 || continue
  "$rt" ps --format '{{.ID}}  {{.Image}}  {{.Names}}' 2>/dev/null >"$EV/system/${rt}_ps.txt"
  grep -iE 'php|wordpress|drupal|joomla|magento|nextcloud|laravel|matomo|mediawiki|prestashop|moodle' "$EV/system/${rt}_ps.txt" |
    flag REVIEW "Running $rt containers that likely embed PHP (not inspected by this script)" "php_containers_$rt" \
      "Check the PHP version inside each container and run the hunt inside it / on its mounted logs and sessions."
done
# Preserve PHP / web server configuration (small text files; needed to interpret everything else)
find /etc/php* /etc/php.ini /etc/php-fpm* /etc/opt/remi /opt/cpanel/ea-php*/root/etc /opt/alt/php*/etc \
     /etc/apache2 /etc/httpd /etc/nginx /usr/local/lsws/conf /usr/local/apache/conf \
     -type f \( -name '*.ini' -o -name '*.conf' -o -name '*.load' -o -name 'php.ini*' \) -size -1M 2>/dev/null | preserve config
note "PHP/Apache/nginx/LiteSpeed configuration preserved to evidence/files/config/"

# --------------------------------------------------------------------------
section "2. Web server / PHP error logs (modified since $SINCE_NORM UTC)"
LOGROOTS=(/var/log/apache2 /var/log/httpd /var/log/nginx /var/log/php* /var/log/litespeed
          /usr/local/lsws/logs /usr/local/apache/logs /var/www/vhosts/*/logs /var/www/*/logs /home/*/logs /opt/bitnami/*/logs)
INI_ERRLOGS=$(grep -rhsE '^[[:space:]]*(error_log|php_admin_value\[error_log\]|php_value\[error_log\])[[:space:]]*=' \
               /etc/php* /etc/php.ini /etc/php-fpm* /etc/opt/remi /opt/cpanel/ea-php*/root/etc /opt/alt/php*/etc 2>/dev/null |
             sed -E "s/^[^=]*=[[:space:]]*//; s/[\"' ]//g" | grep '^/' | sort -u)
LOGS=()
if [ ${#LOGROOTS[@]} -gt 0 ]; then
  mapfile -t LOGS < <( {
    find "${LOGROOTS[@]}" -maxdepth 3 -type f -newer "$REF" 2>/dev/null
    for e in $INI_ERRLOGS; do for g in "$e"*; do [ -f "$g" ] && [ "$g" -nt "$REF" ] && echo "$g"; done; done
  } | sort -u )
fi
ERRLOGS=(); ACCLOGS=()
for l in "${LOGS[@]}"; do
  case "$l" in
    *access*|*request_log*) ACCLOGS+=("$l") ;;
    *.bz2|*.xz|*.zst) ;;                                  # not readable by zgrep - preserved below, scan manually
    *) ERRLOGS+=("$l") ;;
  esac
done
# Collect the logs themselves, newest first, until the cap is reached
AUXLOGS=(/var/log/auth.log* /var/log/secure* /var/log/audit/audit.log* /var/log/kern.log*)
{ printf '%s\n' "${LOGS[@]}"; for a in "${AUXLOGS[@]}"; do [ "$a" -nt "$REF" ] && echo "$a"; done; } |
  grep -v '^$' | xargs -r -d '\n' ls -1t -- 2>/dev/null | tee "$EV/logs_in_scope.txt" | preserve logs
note "${#ERRLOGS[@]} error logs + ${#ACCLOGS[@]} access logs scanned; $(wc -l <"$EV/logs_in_scope.txt") logs in scope (incl. auth/audit/kern), $((COPIED_LOG_BYTES/1048576)) MB copied to evidence/files/logs (cap ${LOGCAP_MB} MB, see collected_files.tsv)"
if [ ${#ERRLOGS[@]} -gt 0 ]; then
  zgrep -HE '(Allowed memory size|tried to allocate).*in Unknown on line 0' "${ERRLOGS[@]}" 2>/dev/null |
    flag HIGH "PHP fatal OOM 'in Unknown on line 0' (PHP2Shell exploit signature)" err_oom_unknown \
      "Client-reportable as attempted exploitation. Match timestamps to access logs for the source IP, then check sections 4/5/7 for success."
  zgrep -hE 'AH00052: child pid [0-9]+ exit signal' "${ERRLOGS[@]}" 2>/dev/null | cut -c2-14 | sort | uniq -c | sort -rn >"$TMPD/crash_hourly"
  CSEV=INFO; [ "$(awk 'NR==1{print $1+0}' "$TMPD/crash_hourly")" -ge 20 ] 2>/dev/null && CSEV=REVIEW
  flag "$CSEV" "Apache child crashes per hour (AH00052)" err_apache_crash_hourly \
    "Dozens+ in one hour = ASLR brute-force pattern; a handful is normal." <"$TMPD/crash_hourly"
  zgrep -HE 'child [0-9]+ exited on signal (4|6|7|11)|segfault' "${ERRLOGS[@]}" 2>/dev/null |
    flag "REVIEW>=5" "PHP-FPM / worker crashes (SIGSEGV/SIGABRT/SIGBUS)" err_fpm_crash "Bursts match the brute-force pattern; occasional crashes are normal."
  zgrep -HE 'Session ID is too long or contains illegal characters|session_start\(\): Failed to (read|decode) session data|in Unknown on line 0' "${ERRLOGS[@]}" 2>/dev/null |
    grep -vE 'Allowed memory size|tried to allocate' |
    flag "REVIEW>=10" "Pre-script warnings / session anomalies ('Unknown on line 0', illegal session IDs)" err_prescript_session \
      "Often startup/config noise. Only matters if clustered with the OOM signature or crash bursts."
else
  note "no error logs found - check custom ErrorLog / error_log locations and rerun"
fi
{ journalctl -k --since "$SINCE_NORM" --no-pager -o short-iso 2>/dev/null; dmesg -T 2>/dev/null
  for k in /var/log/kern.log* /var/log/messages*; do [ "$k" -nt "$REF" ] && zcat -f -- "$k" 2>/dev/null; done
} | grep -E 'segfault|general protection' | grep -E 'php|apache2|httpd|lsphp|frankenphp' | sort -u |
  flag "REVIEW>=5" "Kernel-logged segfaults in PHP/web workers" kernel_segfaults "Bursts match the brute-force pattern; occasional crashes are normal."
if command -v journalctl >/dev/null 2>&1; then
  journalctl --since "$SINCE_NORM" --no-pager -o short-iso -k >"$EV/system/journal_kernel.txt" 2>/dev/null
  journalctl --since "$SINCE_NORM" --no-pager -o short-iso -u 'php*' -u 'apache2*' -u 'httpd*' -u 'nginx*' -u 'lsws*' \
    >"$EV/system/journal_web_units.txt" 2>/dev/null
fi

# --------------------------------------------------------------------------
section "3. Access logs (modified since $SINCE_NORM UTC)"
if [ ${#ACCLOGS[@]} -gt 0 ]; then
  zgrep -Hw -F "${IOC_ARGS[@]}" "${ACCLOGS[@]}" 2>/dev/null |
    flag HIGH "Requests from published PHP2Shell source IPs" acc_ioc_ips \
      "Client-reportable as targeted. Shared anonymiser IPs: proves attempts, not compromise - check sections 4/5/7. Do not just auto-block."
  zgrep -Hi 'php2shell' "${ACCLOGS[@]}" 2>/dev/null |
    flag HIGH "php2shell scanner user-agent (e.g. php2shell-scan/109618)" acc_ioc_ua \
      "Client-reportable as targeted by the PHP2Shell scanner. Check sections 4/5/7 for signs it succeeded."
  for l in "${ACCLOGS[@]}"; do
    zcat -f -- "$l" 2>/dev/null |
      awk -v f="$l" '$6=="\"POST" { k=$1" "substr($4,2,17); c[k]++ } END { for (k in c) if (c[k]>=10) print c[k], k, f }'
  done | sort -rn |
    flag REVIEW "POST bursts >=10/min from one client IP" acc_post_bursts \
      "Could be brute-forcing or a busy form/API. Behind Cloudflare/a load balancer these are proxy IPs unless the real client IP is logged."
  note "Request body size is not in default combined logs: add %I (Apache mod_logio) / \$request_length (nginx) to see oversized POSTs."
else
  note "no access logs found"
fi

# --------------------------------------------------------------------------
section "4. PHP session files (session.upload_progress write primitive)"
SESSDIRS=$( {
  grep -rhsE '^[[:space:]]*(session\.save_path|php_value\[session\.save_path\]|php_admin_value\[session\.save_path\])[[:space:]]*=' \
       /etc/php* /etc/php.ini /etc/php-fpm* /etc/opt/remi /opt/cpanel/ea-php*/root/etc /opt/alt/php*/etc 2>/dev/null |
    sed -E "s/^[^=]*=[[:space:]]*//; s/[\"' ]//g; s/.*;//"
  printf '%s\n' /var/lib/php/sessions /var/lib/php/session /var/lib/php*/session* /var/cpanel/php/sessions/* \
                /opt/alt/php*/var/lib/php/session /tmp /var/tmp
} | grep '^/' | sort -u )
for d in $SESSDIRS; do [ -d "$d" ] && [ "$d" != "$OUT" ] && find "$d" -maxdepth 3 -type f -name 'sess_*' ! -path "$OUT/*" 2>/dev/null; done |
  sort -u >"$EV/session_files_inspected.txt"
note "$(wc -l <"$EV/session_files_inspected.txt") session files inspected under: $(echo $SESSDIRS)"
: >"$TMPD/sess_hits"; : >"$TMPD/sess_code"; : >"$TMPD/sess_prog"
while IFS= read -r s; do
  if grep -aqE '<\?php|<\?=|upload_progress_' "$s" 2>/dev/null; then
    echo "$s" >>"$TMPD/sess_hits"
    line=$(printf '%s  owner=%s  mtime=%s  :: %s' "$s" "$(stat -c %U "$s")" "$(stat -c %y "$s" | cut -c1-19)Z" \
      "$(grep -aoE '.{0,40}(<\?php|<\?=|upload_progress_).{0,120}' "$s" | head -n1 | tr -cd '[:print:]')")
    if grep -aqE '<\?php|<\?=' "$s"; then echo "$line" >>"$TMPD/sess_code"; else echo "$line" >>"$TMPD/sess_prog"; fi
  fi
done <"$EV/session_files_inspected.txt"
flag CRITICAL "Session files containing PHP code (<?php / <?=)" session_php_code \
  "PHP2Shell write primitive used. Escalate. Files preserved in evidence/files/sessions; purge session.save_path only after the archive is verified off-host." <"$TMPD/sess_code"
flag REVIEW "Session files with leftover upload_progress_ entries (no PHP code)" session_upload_progress \
  "Can be legitimate upload-progress use; matters if the site has no upload-progress feature or timestamps match attack traffic." <"$TMPD/sess_prog"
preserve sessions <"$TMPD/sess_hits"
note "redis/memcached session handlers are not covered - search those stores for the same strings."

# --------------------------------------------------------------------------
section "5. Process lineage"
awk -v wp="$WEBPROC_RE" -v tr="$TOOL_RE" 'NR==FNR { c[$1]=$4; next } (c[$2] ~ wp) && ($4 ~ tr)' "$EV/ps_raw.txt" "$EV/ps_raw.txt" |
  flag CRITICAL "LIVE: shells / interpreters / net tools whose parent is a web or PHP worker" proc_web_children \
    "Escalate now. Check the command line - a few apps shell out legitimately (ImageMagick, wkhtmltopdf); recon/download commands = live compromise. Do not restart; details in evidence/proc/<pid>."
awk -v ur="$WEBUSER_RE" -v tr="$TOOL_RE" -v wp="$WEBPROC_RE" 'NR==FNR { c[$1]=$4; next } ($3 ~ ur) && ($4 ~ tr) && !(c[$2] ~ wp)' "$EV/ps_raw.txt" "$EV/ps_raw.txt" |
  flag REVIEW "LIVE: shells / interpreters / net tools running AS a web user (not direct worker children)" proc_webuser_tools \
    "Web-user cron jobs (wp-cron, artisan schedule) look like this. Reverse shells (nc/socat/bash -i, python -c) = escalate."
WEBUID_LIST=" ${WEBUIDS[*]} "
: >"$TMPD/proc_tmp"; : >"$TMPD/proc_tmp_web"; : >"$TMPD/proc_deleted"
for p in /proc/[0-9]*; do
  exe=$(readlink "$p/exe" 2>/dev/null) || continue
  comm=$(cat "$p/comm" 2>/dev/null); puid=$(stat -c %u "$p" 2>/dev/null)
  case "$exe" in
    /tmp/*|/var/tmp/*|/dev/shm/*|/run/user/*|/memfd:*)
      if [[ "$WEBUID_LIST" == *" $puid "* ]]; then echo "${p#/proc/} $comm uid=$puid $exe" >>"$TMPD/proc_tmp_web"
      else echo "${p#/proc/} $comm uid=$puid $exe" >>"$TMPD/proc_tmp"; fi ;;
    *' (deleted)') [[ "$comm" =~ $WEBPROC_RE ]] || echo "${p#/proc/} $comm uid=$puid $exe" >>"$TMPD/proc_deleted" ;;
  esac
done
flag CRITICAL "LIVE: web-user processes executing from /tmp, /dev/shm or memory (memfd)" proc_tmp_web \
  "Dropped-payload pattern - escalate. Executable image saved to evidence/proc/<pid>." <"$TMPD/proc_tmp_web"
flag "$(gsev)" "LIVE: other processes executing from /tmp, /dev/shm or memory (memfd)" proc_tmp \
  "Some installers/agents do this; unknown binaries = escalate." <"$TMPD/proc_tmp"
flag INFO "LIVE: processes running a deleted binary (normally package upgrades awaiting restart)" proc_deleted <"$TMPD/proc_deleted"
for s in proc_web_children proc_webuser_tools proc_tmp_web proc_tmp; do
  [ -f "$EV/$s.txt" ] || continue
  awk '{print $1}' "$EV/$s.txt" | while read -r pid; do capture_proc "$pid" "$s"; done
done
[ -n "$(ls -A "$EV/proc" 2>/dev/null)" ] && note "flagged processes: cmdline/environ/maps/fds and executable image saved to evidence/proc/<pid>/"
AUDIT=(/var/log/audit/audit.log*)
if [ ${#AUDIT[@]} -gt 0 ] && [ -n "$WEBUID_RE" ]; then
  grep -hE "type=SYSCALL.* uid=($WEBUID_RE) .*exe=\"[^\"]*/(sh|bash|dash|python[0-9.]*|perl|curl|wget|nc|ncat|socat|base64|openssl|busybox)\"" "${AUDIT[@]}" 2>/dev/null |
    flag CRITICAL "HISTORY (auditd): shells/tools executed by web-user UIDs" auditd_webuser_exec \
      "Escalate unless explained by a known web-user cron job or app feature - check the full audit records."
fi

# --------------------------------------------------------------------------
section "6. Network (live)"
grep -wF -f "$IOC_IPS" "$EV/ss_tcp.txt" "$EV/ss_udp.txt" 2>/dev/null |
  flag HIGH "Live sockets to published PHP2Shell source IPs" net_ioc \
    "Inbound to 80/443 = active attempt (client-reportable). Any other port or an outbound session = treat as compromise and escalate."
if [ -n "$WEBUID_RE" ]; then
  ss -tnpe state established 2>/dev/null | grep -E "uid:($WEBUID_RE)\b" |
    awk '$3 !~ /:(80|443|8080|8443|9000)$/ && $4 !~ /^(127\.|\[::1\]|\[::ffff:127\.)/' |
    flag REVIEW "Established TCP owned by web users (excl. web/FPM ports and loopback)" net_webuser_outbound "DB/API calls are normal; unknown hosts or odd ports are not."
  ss -tlnpe 2>/dev/null | grep -E "uid:($WEBUID_RE)\b" | awk '$4 !~ /:(80|443|8080|8443|9000)$/' |
    flag HIGH "Listening sockets owned by web users on non-standard ports" net_webuser_listen \
      "Bind-shell pattern unless it is a known app port (Node/queue workers). Unknown = escalate."
fi

# --------------------------------------------------------------------------
section "7. Files changed since $SINCE_NORM UTC"
: >"$EV/webroot_changed.txt"
if [ ${#WEBROOTS[@]} -gt 0 ]; then
  find "${WEBROOTS[@]}" -xdev -type f \( "${PHPEXT_FIND[@]}" -o -name '.user.ini' -o -name '.htaccess' -o -iname 'php.ini' \) \
       \( -newer "$REF" -o -cnewer "$REF" \) -printf '%TY-%Tm-%TdT%TH:%TM:%.2TSZ\t%CY-%Cm-%CdT%CH:%CM:%.2CSZ\t%u\t%s\t%p\n' 2>/dev/null |
    sort >"$EV/webroot_changed.txt"
  note "$(wc -l <"$EV/webroot_changed.txt") PHP/config files changed in web roots (evidence/webroot_changed.txt: mtime, ctime, owner, size, path) - diff against deploy history"
  cut -f5- "$EV/webroot_changed.txt" | tr '\n' '\0' | xargs -0 -r grep -lE "$SHELL_RE" 2>/dev/null >"$TMPD/ws_files"
  UPL_RE='/(uploads?|files|images?|media|cache|tmp)/'
  tr '\n' '\0' <"$TMPD/ws_files" | xargs -0 -r grep -HnE "$SHELL_RE" 2>/dev/null | cut -c1-300 >"$TMPD/ws_hits"
  grep -E "^[^:]*$UPL_RE" "$TMPD/ws_hits" |
    flag CRITICAL "Webshell functions in a NEW/CHANGED script inside an upload/cache/image folder" webshell_in_upload_dir \
      "Classic dropped webshell. Escalate; do not browse to it. Copy preserved in evidence/files/webshell_candidates."
  grep -vE "^[^:]*$UPL_RE" "$TMPD/ws_hits" |
    flag REVIEW "Changed application code containing exec/eval-style functions" webshell_candidates \
      "Frameworks and normal deployments trigger this (very noisy on dev servers). Confirm with the client/dev team the changes were theirs; look for small, obfuscated or oddly named files."
  preserve webshell_candidates <"$TMPD/ws_files"
  cut -f5- "$EV/webroot_changed.txt" | grep -E '/(\.user\.ini|\.htaccess|php\.ini)$' | tr '\n' '\0' |
    xargs -0 -r grep -liE 'auto_(prepend|append)_file|AddHandler|SetHandler|AddType.*php' 2>/dev/null >"$TMPD/ini_files"
  tr '\n' '\0' <"$TMPD/ini_files" | xargs -0 -r grep -HiE 'auto_(prepend|append)_file|AddHandler|SetHandler|AddType.*php' 2>/dev/null >"$TMPD/ini_hits"
  grep -iE 'auto_(prepend|append)_file' "$TMPD/ini_hits" | grep -viE 'wordfence-waf\.php|_file[[:space:]]*=[[:space:]]*("")?(none)?[[:space:]]*$' |
    flag CRITICAL "Changed .user.ini / .htaccess / php.ini adds auto_prepend/append_file" ini_prepend_persistence \
      "Runs code before every PHP request unless it is a known product. Verify the referenced file; unknown = escalate."
  grep -viE 'auto_(prepend|append)_file' "$TMPD/ini_hits" |
    flag REVIEW "Changed .htaccess handler directives (AddHandler/SetHandler/AddType)" ini_handler_changes \
      "Look for PHP execution enabled on image/upload folders; normal site config otherwise."
  preserve ini_persistence <"$TMPD/ini_files"
  find "${WEBROOTS[@]}" -xdev -type f "${PHPEXT_FIND[@]}" \( -path '*/uploads/*' -o -path '*/upload/*' -o -path '*/files/*' \
       -o -path '*/images/*' -o -path '*/media/*' -o -path '*/cache/*' -o -path '*/tmp/*' \) \
       ! \( -name 'index.php' -size -200c \) 2>/dev/null >"$TMPD/upl_files"
  flag REVIEW "PHP files inside upload/cache/image dirs (any age)" php_in_upload_dirs \
    "Upload folders should not hold scripts; some CMS caches do. Unknown or recently added ones = escalate." <"$TMPD/upl_files"
  preserve php_in_upload_dirs <"$TMPD/upl_files"
fi
UARGS=(); for u in "${WEBUSERS[@]}"; do UARGS+=(-o -user "$u"); done
if [ ${#UARGS[@]} -gt 0 ]; then
  find /tmp /var/tmp /dev/shm -xdev \( "${UARGS[@]:1}" \) \( -newer "$REF" -o -cnewer "$REF" \) ! -path "$OUT/*" \
       -printf '%TY-%Tm-%TdT%TH:%TM:%.2TSZ\t%u\t%M\t%s\t%p\n' 2>/dev/null | grep -v '/sess_' | sort >"$TMPD/tmp_files"
  flag REVIEW "Files in /tmp, /var/tmp, /dev/shm owned by web users and changed in the window (excl. sess_*)" tmp_webuser_files \
    "Apps write caches/uploads here; scripts, ELF binaries or archives = escalate." <"$TMPD/tmp_files"
  cut -f5- "$TMPD/tmp_files" | preserve tmp_webuser_files
fi

# --------------------------------------------------------------------------
section "8. Persistence"
for u in "${WEBUSERS[@]}"; do
  crontab -l -u "$u" 2>/dev/null | grep -vE '^[[:space:]]*(#|$)' | sed "s|^|$u: |"
done >"$TMPD/cron_web"
CRON_BAD='curl|wget|base64|/tmp/|/dev/shm|[^a-z]nc |ncat|socat|bash -i|python[0-9.]* -c|perl -e|/dev/tcp'
grep -E "$CRON_BAD" "$TMPD/cron_web" | flag CRITICAL "Web-user crontab entries that download, decode or open shells" cron_webusers_suspicious \
  "Classic post-exploitation persistence - escalate."
grep -vE "$CRON_BAD" "$TMPD/cron_web" | flag REVIEW "Other crontab entries for web users" cron_webusers "Usually app schedulers (wp-cron, artisan). Confirm with the client."
find /etc/crontab /etc/cron.d /etc/cron.hourly /etc/cron.daily /etc/cron.weekly /etc/cron.monthly /etc/anacrontab /var/spool/cron \
     -type f \( -newer "$REF" -o -cnewer "$REF" \) 2>/dev/null >"$TMPD/cron_files"
flag "$(gsev)" "System cron files changed in the window" cron_changed "Package updates touch these; check new/unknown jobs." <"$TMPD/cron_files"
preserve persistence <"$TMPD/cron_files"
find /var/spool/cron -type f 2>/dev/null | preserve crontabs_all
{ [ ${#HOMES[@]} -gt 0 ] && find "${HOMES[@]}" -maxdepth 3 -name 'authorized_keys*' 2>/dev/null
  [ ${#WEBROOTS[@]} -gt 0 ] && find "${WEBROOTS[@]}" -xdev -name 'authorized_keys*' 2>/dev/null
} | sort -u >"$TMPD/ssh_web"
find /root /home /etc/ssh -xdev -name 'authorized_keys*' \( -newer "$REF" -o -cnewer "$REF" \) 2>/dev/null | sort -u | grep -vxF -f "$TMPD/ssh_web" >"$TMPD/ssh_other"
flag CRITICAL "authorized_keys under web-user homes or web roots" ssh_keys_web "Web users should never have SSH keys - escalate." <"$TMPD/ssh_web"
flag "$(gsev)" "Other authorized_keys changed in the window" ssh_keys "Confirm each key change with the client's admins." <"$TMPD/ssh_other"
cat "$TMPD/ssh_web" "$TMPD/ssh_other" >"$TMPD/ssh_files"
preserve persistence <"$TMPD/ssh_files"
{ [ ${#HOMES[@]} -gt 0 ] && find "${HOMES[@]}" -maxdepth 4 \( -path '*/.config/systemd/*' -o -name '.bashrc' -o -name '.profile' -o -name '.bash_profile' -o -name '.bash_history' \) -type f 2>/dev/null; } >"$TMPD/home_files"
flag REVIEW "Shell-init / history / user systemd units in web-user homes" webuser_homes_init \
  "A .bash_history or user systemd unit for a web user means someone got a shell as it - read them." <"$TMPD/home_files"
preserve persistence <"$TMPD/home_files"
find /etc/passwd /etc/shadow /etc/group /etc/sudoers /etc/sudoers.d /etc/ld.so.preload /etc/systemd/system /etc/init.d /etc/rc.local /etc/profile.d \
     /lib/systemd/system /usr/lib/systemd/system \
     -type f \( -newer "$REF" -o -cnewer "$REF" \) 2>/dev/null >"$TMPD/sys_files"
flag "$(gsev)" "Account / sudo / systemd / init files changed in the window" sys_files_changed \
  "Package updates touch many of these - correlate with apt/yum history; new users, sudoers entries or unknown units = escalate." <"$TMPD/sys_files"
grep -v '^/etc/shadow$' "$TMPD/sys_files" | preserve persistence
{ [ -s /etc/ld.so.preload ] && cat /etc/ld.so.preload; } | flag REVIEW "/etc/ld.so.preload in use" ld_preload \
  "Rootkit technique; a few security agents use it legitimately. Unknown library = escalate."
getent passwd | awk -F: -v re="$WEBUSER_RE" '$1 ~ re && $7 !~ /(nologin|false|sync)$/' |
  flag "$(gsev)" "Web users with an interactive login shell" webuser_shells "Hardening issue, not a compromise indicator on its own."

# --------------------------------------------------------------------------
section "9. Telemetry coverage"
note "auditd execve rules loaded: $(auditctl -l 2>/dev/null | grep -c execve)"
note "EDR/agent processes seen: $(ps -eo comm= | grep -iE 'falcon|sentinel|s1-agent|wazuh|ossec|elastic|huntress|mdatp|wdavdaemon|sophos|velociraptor|osquery|process-watch' | sort -u | tr '\n' ' ')"
note "persistent journald: $([ -d /var/log/journal ] && echo yes || echo no)"
note "Without process telemetry, sections 5/6 only show what is running NOW. Memory disclosure (CVE-2026-109619) leaves no host artifacts at all."

# --------------------------------------------------------------------------
# Evidence packaging: summary, chain of custody, manifest, archive, archive hash
rm -rf "$TMPD"
END_UTC="$(date -u +%FT%TZ)"
# ---------------------------------------------------------------- verdict
declare -A CNT=([CRITICAL]=0 [HIGH]=0 [REVIEW]=0 [INFO]=0)
for i in "${!R_SEV[@]}"; do CNT[${R_SEV[$i]}]=$(( ${CNT[${R_SEV[$i]}]} + 1 )); done
REASONS=()
for i in "${!R_SEV[@]}"; do
  [ "${R_SEV[$i]}" = HIGH ] || continue
  case "${R_SLUG[$i]}" in
    php_vulnerable_serving|stale_runtimes) [[ " ${REASONS[*]} " == *"patch"* ]] || REASONS+=("vulnerable PHP is serving web requests - patch") ;;
    acc_ioc_ips|acc_ioc_ua|err_oom_unknown|net_ioc) [[ " ${REASONS[*]} " == *"attempts"* ]] || REASONS+=("exploitation attempts seen (no proof of success)") ;;
    *) [[ " ${REASONS[*]} " == *"indicators"* ]] || REASONS+=("high-risk indicators to confirm") ;;
  esac
done
if [ "${CNT[CRITICAL]}" -gt 0 ]; then
  VERDICT="COMPROMISE SUSPECTED"; EXITCODE=5; VCOL=31
  TELL="YES - escalate to incident response now. Do not restart/patch until evidence is off the host."
elif [ "${CNT[HIGH]}" -gt 0 ]; then
  VERDICT="ACTION REQUIRED"; EXITCODE=4; VCOL=33
  TELL="YES - $(IFS=';'; echo "${REASONS[*]}" | sed 's/;/; /g')"
elif [ "${CNT[REVIEW]}" -gt 0 ]; then
  VERDICT="REVIEW"; EXITCODE=3; VCOL=36
  TELL="NOT YET - analyst to check the REVIEW items below first (usually benign)"
elif [ "$PHP_SERVING" -eq 1 ]; then
  VERDICT="CLEAN"; EXITCODE=0; VCOL=32; TELL="NO ACTION - patched PHP and no indicators (report as checked / clean)"
else
  VERDICT="NOT EXPOSED"; EXITCODE=0; VCOL=32; TELL="NO ACTION - PHP is not serving web requests on this host"
fi
if [ "$PHP_SERVING" -eq 1 ]; then
  EXPOSURE="PHP serving web requests: $(grep '^RUNNING: ' "$EV/php_versions.txt" | sed -E 's/^RUNNING: +//; s/ +/ /g' | awk '{n=split($1,a,"/"); printf "%s%s %s (%s)", (NR>1?"; ":""), a[n], $2, ($3=="patched"?"patched":($3=="EOL"?"EOL":"vulnerable"))}')"
  [ "$EXPOSURE" = "PHP serving web requests: " ] && EXPOSURE="PHP serving web requests (running version not readable - see php_versions.txt)"
elif [ -s "$EV/php_versions.txt" ]; then EXPOSURE="PHP installed but NOT serving web requests (CLI only)"
elif [ ${#WEBROOTS[@]} -gt 0 ] || [ ${#LOGS[@]} -gt 0 ]; then EXPOSURE="No PHP binaries/processes found (web roots or web logs exist - check containers / remote PHP-FPM)"
else EXPOSURE="No PHP found"; fi
_pc=("$EV"/php_containers_*.txt); [ ${#_pc[@]} -gt 0 ] && EXPOSURE="$EXPOSURE; PHP containers present (not inspected)"
EDR_SEEN=$(ps -eo comm= 2>/dev/null | grep -ciE 'falcon|sentinel|s1-agent|wazuh|ossec|elastic|huntress|mdatp|wdavdaemon|sophos|velociraptor|osquery')
if [ "$(id -u)" -ne 0 ]; then CONF="LOW - not run as root"
elif [ "$PHP_SERVING" -ne 1 ]; then CONF="n/a - not exposed"
elif [ "$(auditctl -l 2>/dev/null | grep -c execve)" -eq 0 ] && [ "${EDR_SEEN:-0}" -eq 0 ]; then
  CONF="MEDIUM - no process history (auditd execve / EDR): past shells would be missed, only live state checked"
else CONF="GOOD"; fi
RULE="$(printf '=%.0s' {1..78})"
{
  echo "$RULE"
  echo " PHP2Shell triage   $HOST   $START_UTC   v$VERSION"
  echo " VERDICT     : $VERDICT"
  echo " TELL CLIENT : $TELL"
  echo " Exposure    : $EXPOSURE"
  echo " Confidence  : $CONF"
  echo " Counts      : CRITICAL ${CNT[CRITICAL]}  HIGH ${CNT[HIGH]}  REVIEW ${CNT[REVIEW]}   (INFO ${CNT[INFO]} - context only, not counted)"
  echo "$RULE"
  for sv in CRITICAL HIGH REVIEW; do
    for i in "${!R_SEV[@]}"; do
      [ "${R_SEV[$i]}" = "$sv" ] || continue
      echo "[$sv] ${R_LABEL[$i]}  (${R_N[$i]})"
      [ -n "${R_ACT[$i]}" ] && echo "    -> ${R_ACT[$i]}"
      [ -n "${R_S1[$i]}" ] && echo "       e.g. ${R_S1[$i]}"
      [ -n "${R_S2[$i]}" ] && echo "       e.g. ${R_S2[$i]}"
      echo "       full list: evidence/${R_SLUG[$i]}.txt"
    done
  done
  if [ "${CNT[INFO]}" -gt 0 ]; then
    echo; echo "Context only (not counted):"
    for i in "${!R_SEV[@]}"; do [ "${R_SEV[$i]}" = INFO ] && echo "    [INFO] ${R_LABEL[$i]}  (${R_N[$i]}) - evidence/${R_SLUG[$i]}.txt"; done
  fi
  echo "$RULE"
} >"$OUT/.verdict_block"
{ cat "$OUT/.verdict_block"; echo; echo "DETAIL"; echo "------"; cat "$F"; } >"$F.new" && mv "$F.new" "$F"
jesc(){ local x="$1"; x=${x//\\/\\\\}; x=${x//\"/\\\"}; x=${x//$'\t'/ }; x=${x//$'\r'/}; x=${x//$'\n'/ }; printf '%s' "$x" | tr -d '\000-\037'; }
write_summary(){   # $1 = file, $2 = archive path, $3 = archive sha
  {
    printf '{\n  "Host": "%s",\n  "OS": "%s",\n  "RunUtc": "%s",\n  "SinceUtc": "%s",\n  "ScriptVersion": "%s",\n' \
      "$(jesc "$HOST")" "$(jesc "$(. /etc/os-release 2>/dev/null; echo "${PRETTY_NAME:-Linux}")")" "$START_UTC" "$(jesc "$SINCE_NORM")Z" "$VERSION"
    printf '  "CaseId": "%s",\n  "Analyst": "%s",\n  "Verdict": "%s",\n  "TellClient": "%s",\n  "Exposure": "%s",\n  "Confidence": "%s",\n  "ExitCode": %s,\n' \
      "$(jesc "$CASE_ID")" "$(jesc "$ANALYST")" "$VERDICT" "$(jesc "$TELL")" "$(jesc "$EXPOSURE")" "$(jesc "$CONF")" "$EXITCODE"
    printf '  "Counts": { "CRITICAL": %s, "HIGH": %s, "REVIEW": %s, "INFO": %s },\n' "${CNT[CRITICAL]}" "${CNT[HIGH]}" "${CNT[REVIEW]}" "${CNT[INFO]}"
    printf '  "PhpVersions": ['
    local first=1 l i sv
    while IFS= read -r l; do [ -z "$l" ] && continue; [ $first -eq 1 ] || printf ','; first=0; printf '\n    "%s"' "$(jesc "$(echo "$l" | sed -E 's/ +/ /g')")"; done <"$EV/php_versions.txt"
    printf '\n  ],\n  "Findings": ['
    first=1
    for sv in CRITICAL HIGH REVIEW INFO; do
      for i in "${!R_SEV[@]}"; do
        [ "${R_SEV[$i]}" = "$sv" ] || continue
        [ $first -eq 1 ] || printf ','; first=0
        printf '\n    { "Severity": "%s", "Check": "%s", "Finding": "%s", "Count": %s, "Action": "%s", "Sample": ["%s", "%s"] }' \
          "$sv" "${R_SLUG[$i]}" "$(jesc "${R_LABEL[$i]}")" "${R_N[$i]}" "$(jesc "${R_ACT[$i]}")" "$(jesc "${R_S1[$i]}")" "$(jesc "${R_S2[$i]}")"
      done
    done
    printf '\n  ],\n  "Archive": "%s",\n  "ArchiveSha256": "%s"\n}\n' "$(jesc "$2")" "$3"
  } >"$1"
}
write_summary "$OUT/summary.json" "" ""
SCRIPT_SHA=$(sha "$0")
{
  echo "CHAIN OF CUSTODY / COLLECTION RECORD"
  echo "====================================="
  echo "Case reference      : $CASE_ID"
  echo "Analyst             : $ANALYST"
  echo "Executed as         : $(id -un) (uid $(id -u)), sudo user: ${SUDO_USER:-n/a}"
  echo "Host                : $HOST  (FQDN: $(hostname -f 2>/dev/null))"
  echo "Host IPs            : $(hostname -I 2>/dev/null)"
  echo "Machine ID          : $(cat /etc/machine-id 2>/dev/null)"
  echo "OS / kernel         : $(. /etc/os-release 2>/dev/null; echo "${PRETTY_NAME:-unknown}") / $(uname -r)"
  echo "Host time zone      : $HOST_TZ"
  echo "Collection start    : $START_UTC (UTC)   [host local: $START_LOCAL]"
  echo "Collection end      : $END_UTC (UTC)"
  echo "Hunt window since   : $SINCE_NORM UTC"
  echo "Tool                : php2shell_hunt_linux.sh v$VERSION  sha256=$SCRIPT_SHA"
  echo "Options             : logcap=${LOGCAP_MB}MB filecap=${FILECAP_MB}MB coredumps=$DUMPS webroots=${WEBROOTS[*]}"
  echo "Output directory    : $OUT"
  echo "Files preserved     : $(($(wc -l <"$COLL")-1)) entries in evidence/collected_files.tsv"
  echo "Verdict at capture  : $VERDICT  (CRITICAL ${CNT[CRITICAL]} / HIGH ${CNT[HIGH]} / REVIEW ${CNT[REVIEW]})"
  echo "Integrity           : every file listed in SHA256SUMS (verify: cd <dir> && sha256sum -c SHA256SUMS)"
  echo "Archive             : $OUT.tgz  (hash in $OUT.tgz.sha256)"
  echo
  echo "Handling notes: evidence contains live session tokens, credentials in configs/environ, and possibly"
  echo "live webshells/malware. Store encrypted, restrict access, do not open copied files in a browser or PHP."
  echo
  echo "TRANSFER LOG (complete by hand for each hand-off)"
  echo "Date/time (UTC) | Released by | Received by | Purpose / location | Archive SHA256 verified (Y/N)"
  echo "----------------+-------------+-------------+--------------------+------------------------------"
} >"$OUT/chain_of_custody.txt"
log "collection finished; building manifest"
BLOCK_TXT="$(cat "$OUT/.verdict_block")"; rm -f "$OUT/.verdict_block"
( cd "$OUT" && find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 -r sha256sum ) >"$OUT/SHA256SUMS"
chmod -R go-rwx "$OUT"
if TARERR=$(tar -czf "$OUT.tgz" -C "$(dirname "$OUT")" "$(basename "$OUT")" 2>&1); then
  chmod 600 "$OUT.tgz"
  ( cd "$(dirname "$OUT")" && sha256sum "$(basename "$OUT").tgz" ) >"$OUT.tgz.sha256"
  ARCH_SHA=$(cut -d' ' -f1 "$OUT.tgz.sha256")
  ARCH_MSG="Archive: $OUT.tgz  sha256=$ARCH_SHA"
else
  ARCH_MSG="Archive FAILED ($TARERR) - evidence left in $OUT; archive manually"
fi
# Sidecar summary next to the archive (with the archive hash) - safe to share, holds no evidence content
write_summary "$OUT.summary.json" "$OUT.tgz" "${ARCH_SHA:-}"
csvq(){ local x="${1//\"/\"\"}"; printf '"%s"' "$x"; }
TOPF=""; for sv in CRITICAL HIGH REVIEW; do for i in "${!R_SEV[@]}"; do [ "${R_SEV[$i]}" = "$sv" ] && TOPF="${TOPF:+$TOPF | }[$sv] ${R_LABEL[$i]}"; done; done
{
  echo '"Host","RunUtc","Verdict","TellClient","Critical","High","Review","Info","Exposure","Confidence","Findings","Archive","ArchiveSha256","CaseId"'
  printf '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n' "$(csvq "$HOST")" "$(csvq "$START_UTC")" "$(csvq "$VERDICT")" "$(csvq "$TELL")" \
    "$(csvq "${CNT[CRITICAL]}")" "$(csvq "${CNT[HIGH]}")" "$(csvq "${CNT[REVIEW]}")" "$(csvq "${CNT[INFO]}")" "$(csvq "$EXPOSURE")" "$(csvq "$CONF")" \
    "$(csvq "$TOPF")" "$(csvq "$OUT.tgz")" "$(csvq "${ARCH_SHA:-}")" "$(csvq "$CASE_ID")"
} >"$OUT.summary.csv"
chmod 600 "$OUT.summary.json" "$OUT.summary.csv"
SHARE_MSG=""
if [ -n "$RESULT_DIR" ]; then
  if mkdir -p "$RESULT_DIR" 2>/dev/null && cp "$OUT.summary.json" "$OUT.summary.csv" "$RESULT_DIR/" 2>/dev/null; then
    SHARE_MSG="Result copied to $RESULT_DIR"
    if [ "$COPY_EV" -eq 1 ] && [ -n "${ARCH_SHA:-}" ]; then
      if cp "$OUT.tgz" "$OUT.tgz.sha256" "$RESULT_DIR/" 2>/dev/null &&
         [ "$(sha "$RESULT_DIR/$(basename "$OUT").tgz")" = "$ARCH_SHA" ]; then
        SHARE_MSG="$SHARE_MSG; evidence archive copied and hash VERIFIED"
      else
        SHARE_MSG="$SHARE_MSG; evidence archive copy FAILED or hash MISMATCH - keep the local copy"
      fi
    fi
  else
    SHARE_MSG="Copy to $RESULT_DIR FAILED"
  fi
fi
if [ -t 1 ]; then C_OFF=$'\e[0m'; else C_OFF=""; fi
col(){ [ -t 1 ] && printf '\e[%sm' "$1"; }
echo
while IFS= read -r l; do
  case "$l" in
    " VERDICT"*|" TELL CLIENT"*) echo "$(col "1;$VCOL")$l$C_OFF" ;;
    "[CRITICAL]"*) echo "$(col '1;31')$l$C_OFF" ;;
    "[HIGH]"*)     echo "$(col 33)$l$C_OFF" ;;
    "[REVIEW]"*)   echo "$(col 36)$l$C_OFF" ;;
    "       "*|"    [INFO]"*) echo "$(col 90)$l$C_OFF" ;;
    *) echo "$l" ;;
  esac
done <<<"$BLOCK_TXT"
echo "Report : $F"
echo "$ARCH_MSG"
echo "Summary: $OUT.summary.json"
[ -n "$SHARE_MSG" ] && echo "$SHARE_MSG"
echo "Record the archive SHA256 in the case ticket, copy the .tgz + .sha256 off the host, verify, then"
echo "remove $OUT, $OUT.tgz and the summary files from this host (the copy contains sensitive data)."
echo "Exit code $EXITCODE  (0 clean/not exposed, 3 review, 4 action required, 5 compromise suspected)"
exit "$EXITCODE"
