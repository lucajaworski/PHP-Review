#Requires -Version 5.1
<#
.SYNOPSIS
    Read-only compromise triage for PHP2Shell (CVE-2026-109618 / CVE-2026-109619) on Windows.  v2.1
.DESCRIPTION
    Covers IIS + FastCGI (php-cgi.exe), Apache/XAMPP/WAMP/Laragon (php*apache2_4.dll) and bundled vendor PHP.
    Flags indicators AND preserves the evidence behind them (logs, configs, suspicious files, process images,
    event logs) with SHA-256 hashes, a chain-of-custody record, a manifest and a hashed archive.
    Changes nothing on the host apart from writing to -OutDir.
    Run elevated, from 64-bit PowerShell, BEFORE recycling app pools / restarting Apache: restarts wipe worker state.
    All timestamps written by this script are UTC (suffix Z).
.PARAMETER Since
    Start of the hunt window. A date without an offset is read as UTC (default 2026-10-17 = earliest exploitation
    attempt reported, Amazon MadPot).
.PARAMETER WebRoots
    Extra web roots. IIS site paths and common XAMPP/WAMP/Laragon roots are discovered automatically.
.PARAMETER OutDir
    Output folder. Must not exist yet and must not be inside a web root. Default %SystemDrive%\IR\php2shell_<host>_<utc>.
    Prefer a dedicated evidence volume or mapped secure share.
.PARAMETER CaseId
    Case / ticket reference recorded in the chain-of-custody record.
.PARAMETER Analyst
    Analyst name recorded in the chain-of-custody record (default: current user).
.PARAMETER MaxLogCopyMB
    Total cap for raw log copies (default 2048). Logs over the cap are hashed in place and listed. 0 = copy no logs.
.PARAMETER MaxFileMB
    Cap for any other single preserved file (default 50).
.PARAMETER NoEventLogExport
    Skip exporting the window's event logs to .evtx.
.PARAMETER ProcDumpPath
    OPT-IN: path to Sysinternals procdump.exe. Dumps flagged processes, then PHP/web workers (up to -MaxDumps).
.PARAMETER MaxDumps
    Max number of process memory dumps when -ProcDumpPath is given (default 5).
.PARAMETER DeepScan
    Also search all fixed drives for php.exe / php-cgi.exe bundled inside vendor software (slow).
.PARAMETER VerifyPath
    Verify an existing collection folder against its SHA256SUMS and exit (no collection is run).
.PARAMETER ResultShare
    UNC/folder to drop this host's one-line result (<host>_<utc>.summary.json / .csv) into, for fleet roll-up.
    Contains no sensitive evidence - only the verdict, counts and finding titles.
.PARAMETER CopyEvidenceToShare
    With -ResultShare: also copy the evidence .zip + .sha256 there and verify the hash after copying.
.PARAMETER Summarise
    Read every *.summary.json under a folder (Windows and Linux results) and print a fleet table, worst first;
    writes fleet_summary.csv in that folder. No collection is run.
.NOTES
    Exit codes (for RMM / scripted runs): 0 = CLEAN or NOT EXPOSED, 3 = REVIEW, 4 = ACTION REQUIRED,
    5 = COMPROMISE SUSPECTED, 1 = script error.
    Severity: CRITICAL = signs of compromise; HIGH = vulnerable and serving, or exploitation attempts seen;
    REVIEW = needs an analyst look, often benign; INFO = context only, never counted.
    Generic Windows persistence checks only count (REVIEW) on hosts where PHP is actually serving web requests.
.EXAMPLE
    .\php2shell_hunt_windows.ps1 -CaseId INC-1234 -Analyst 'L. Jaworski'
.EXAMPLE
    .\php2shell_hunt_windows.ps1 -Since 2026-10-17 -WebRoots D:\Sites -OutDir E:\IR\web01 -ProcDumpPath C:\Tools\procdump64.exe
.EXAMPLE
    .\php2shell_hunt_windows.ps1 -VerifyPath E:\IR\php2shell_WEB01_20261022T124500Z
.EXAMPLE
    .\php2shell_hunt_windows.ps1 -CaseId INC-1234 -ResultShare \\fileserver\IR$\php2shell -CopyEvidenceToShare
.EXAMPLE
    .\php2shell_hunt_windows.ps1 -Summarise \\fileserver\IR$\php2shell
#>
[CmdletBinding()]
param(
    [datetime]$Since = '2026-10-17',
    [string[]]$WebRoots = @(),
    [string]$OutDir,
    [string]$CaseId = 'unassigned',
    [string]$Analyst = $env:USERNAME,
    [ValidateRange(0, 1048576)][int]$MaxLogCopyMB = 2048,
    [ValidateRange(1, 4096)][int]$MaxFileMB = 50,
    [switch]$NoEventLogExport,
    [string]$ProcDumpPath,
    [ValidateRange(1, 100)][int]$MaxDumps = 5,
    [switch]$DeepScan,
    [string]$VerifyPath,
    [string]$ResultShare,
    [switch]$CopyEvidenceToShare,
    [string]$Summarise
)

$Version = '2.1'
$Utf8NoBom = New-Object Text.UTF8Encoding $false

$SevRank = @{ 'COMPROMISE SUSPECTED' = 5; 'ACTION REQUIRED' = 4; 'REVIEW' = 3; 'CLEAN' = 1; 'NOT EXPOSED' = 0 }

# ---------------------------------------------------------------- fleet summary mode
if ($Summarise) {
    $rows = @(Get-ChildItem -LiteralPath $Summarise -Recurse -File -Filter '*.summary.json' | ForEach-Object {
        try { Get-Content -LiteralPath $_.FullName -Raw -Encoding UTF8 | ConvertFrom-Json } catch { Write-Warning "unreadable: $($_.FullName)" }
    })
    if (-not $rows.Count) { Write-Error "No *.summary.json found under $Summarise"; exit 2 }
    # keep only the latest run per host
    $latest = $rows | Group-Object Host | ForEach-Object { $_.Group | Sort-Object RunUtc -Descending | Select-Object -First 1 }
    $table = $latest | Sort-Object @{ e = { -1 * [int]$SevRank["$($_.Verdict)"] } }, Host | ForEach-Object {
        [pscustomobject]@{
            Host = $_.Host; OS = $_.OS; RunUtc = $_.RunUtc; Verdict = $_.Verdict; TellClient = $_.TellClient
            Critical = $_.Counts.CRITICAL; High = $_.Counts.HIGH; Review = $_.Counts.REVIEW
            Exposure = $_.Exposure; Confidence = $_.Confidence
            Findings = (@($_.Findings | Where-Object { $_.Severity -ne 'INFO' } | ForEach-Object { '[{0}] {1}' -f $_.Severity, $_.Finding }) -join ' | ')
            Archive = $_.Archive; ArchiveSha256 = $_.ArchiveSha256; CaseId = $_.CaseId
        }
    }
    $table | Format-Table Host, Verdict, Critical, High, Review, Confidence, TellClient -AutoSize -Wrap | Out-String -Width 220 | Write-Host
    $csv = Join-Path $Summarise 'fleet_summary.csv'
    $table | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
    Write-Host ('{0} hosts. Full detail (incl. finding titles): {1}' -f @($table).Count, $csv)
    exit 0
}

# ---------------------------------------------------------------- verify-only mode
if ($VerifyPath) {
    $sums = Join-Path $VerifyPath 'SHA256SUMS'
    if (-not (Test-Path -LiteralPath $sums)) { Write-Error "No SHA256SUMS in $VerifyPath"; exit 2 }
    $bad = 0; $ok = 0
    foreach ($l in [IO.File]::ReadAllLines($sums, $Utf8NoBom)) {
        if ($l -notmatch '^([0-9a-f]{64}) \*(.+)$') { continue }
        $p = Join-Path $VerifyPath ($Matches[2] -replace '/', '\')
        $h = if (Test-Path -LiteralPath $p) { (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant() } else { 'MISSING' }
        if ($h -eq $Matches[1]) { $ok++ } else { $bad++; Write-Host ('FAILED  {0}  ({1})' -f $Matches[2], $h) }
    }
    Write-Host ('{0} OK, {1} FAILED' -f $ok, $bad)
    if ($bad) { exit 1 } else { exit 0 }
}

# ---------------------------------------------------------------- pre-flight
if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess) {
    Write-Error 'Run from 64-bit PowerShell: in 32-bit PowerShell System32\inetsrv (IIS config) is redirected and IIS would be missed.'
    exit 1
}
# A window date without an offset is read as UTC so Windows and Linux runs cover the same window.
if ($Since.Kind -eq [DateTimeKind]::Unspecified) { $Since = [datetime]::SpecifyKind($Since, [DateTimeKind]::Utc).ToLocalTime() }

$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference    = 'SilentlyContinue'
$Error.Clear()
$StartUtc = (Get-Date).ToUniversalTime()

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { Write-Warning 'Not elevated - Security log, other users'' files and process details will be missing.' }

function U($Dt) {
    # Any DateTime -> 'yyyy-MM-ddTHH:mm:ssZ' (true UTC; local/unspecified kinds are converted, not relabelled)
    if ($null -eq $Dt -or "$Dt" -eq '') { return '' }
    try { ([datetime]$Dt).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ') } catch { "$Dt" }
}
function New-StringSet { New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase) }

# ---------------------------------------------------------------- discovery needed before choosing OutDir
$AppHost = Join-Path $env:windir 'System32\inetsrv\config\applicationHost.config'
$IisXml = $null
if (Test-Path -LiteralPath $AppHost) { try { $IisXml = [xml](Get-Content -LiteralPath $AppHost -Raw) } catch { $IisXml = $null } }

$RootSet = New-StringSet
foreach ($r in $WebRoots) { [void]$RootSet.Add($r) }
foreach ($r in @("$env:SystemDrive\inetpub\wwwroot", 'C:\xampp\htdocs', 'C:\wamp64\www', 'C:\wamp\www', 'C:\laragon\www')) { [void]$RootSet.Add($r) }
if ($IisXml) {
    foreach ($pp in @($IisXml.configuration.'system.applicationHost'.sites.site.application.virtualDirectory.physicalPath)) {
        if ($pp) { [void]$RootSet.Add([Environment]::ExpandEnvironmentVariables($pp)) }
    }
}
$Roots = @($RootSet | Where-Object { Test-Path -LiteralPath $_ -PathType Container } | ForEach-Object { [IO.Path]::GetFullPath($_).TrimEnd('\') } | Sort-Object -Unique)

if (-not $OutDir) {
    $OutDir = Join-Path "$env:SystemDrive\IR" ('php2shell_{0}_{1}' -f $env:COMPUTERNAME, $StartUtc.ToString('yyyyMMddTHHmmssZ'))
}
$OutDir = [IO.Path]::GetFullPath($OutDir).TrimEnd('\')
if (Test-Path -LiteralPath $OutDir) { Write-Error "Output folder $OutDir already exists - refusing to mix collections."; exit 1 }
foreach ($r in $Roots) {
    if (($OutDir + '\').StartsWith($r + '\', [StringComparison]::OrdinalIgnoreCase)) {
        Write-Error "Output folder $OutDir is inside web root $r - evidence would be web-reachable. Use -OutDir."; exit 1
    }
}
New-Item -ItemType Directory -Force -Path $OutDir -ErrorAction Stop | Out-Null
# Lock the evidence folder down to Administrators, SYSTEM and the collecting account (SIDs = language independent)
$MySid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$AclArgs     = @('/inheritance:r', '/grant:r', '*S-1-5-32-544:(OI)(CI)F', '*S-1-5-18:(OI)(CI)F', "*${MySid}:(OI)(CI)F")
$FileAclArgs = @('/inheritance:r', '/grant:r', '*S-1-5-32-544:F', '*S-1-5-18:F', "*${MySid}:F")
& icacls.exe $OutDir @AclArgs | Out-Null

$Ev       = Join-Path $OutDir 'evidence'
$FilesDir = Join-Path $Ev 'files'
$ProcDir  = Join-Path $Ev 'proc'
$SysDir   = Join-Path $Ev 'system'
$EvtDir   = Join-Path $Ev 'eventlogs'
$MemDir   = Join-Path $Ev 'memory'
foreach ($d in @($Ev, $FilesDir, $ProcDir, $SysDir, $EvtDir, $MemDir)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
$Findings = Join-Path $OutDir 'findings.txt'
$LogFile  = Join-Path $OutDir 'collection.log'
$CollCsv  = Join-Path $Ev 'collected_files.csv'
$script:LogBytes = 0L
$script:Preserved = New-StringSet

# Published source IPs (Amazon MadPot, VulnCheck). Shared anonymizer infra: investigate, don't auto-block.
$IocIps   = @('103.216.220.92', '31.223.184.166', '37.19.200.5', '134.209.159.64', '103.114.163.188',
              '95.217.98.37', '85.11.167.243', '45.198.224.169', '109.71.252.97')
$IocSet   = New-Object 'System.Collections.Generic.HashSet[string]' (, [string[]]$IocIps)
[IO.File]::WriteAllLines((Join-Path $Ev 'ioc_ips.txt'), [string[]]$IocIps, $Utf8NoBom)
$Fixed    = @{ '8.2' = 35; '8.3' = 36; '8.4' = 27; '8.5' = 12 }
$WebProcRe = '^(php|php-cgi|httpd|w3wp|nginx|caddy|frankenphp|lsphp)\.exe$'
$PhpRe     = '^(php|php-cgi)\.exe$'
$ToolRe    = '^(cmd|powershell|pwsh|certutil|bitsadmin|mshta|rundll32|regsvr32|wscript|cscript|whoami|ipconfig|systeminfo|net|net1|nltest|tasklist|hostname|nslookup|quser|query|reg|sc|schtasks|wmic|curl|wget|tar|ftp|tftp|bash|sh|python|python3|perl|nc|ncat|plink|ssh|msbuild|installutil|csc|vssadmin|wevtutil|ntdsutil|procdump|rclone|7z|7za)\.exe$'
$ShellRe   = '(eval|assert|create_function)\s*\(|base64_decode\s*\(|gz(inflate|uncompress|decode)\s*\(|str_rot13\s*\(|(shell_exec|passthru|system|proc_open|popen|pcntl_exec)\s*\(|(?<![\w>])exec\s*\(|fsockopen\s*\(|\$_(POST|GET|REQUEST|COOKIE)\s*\[|Process\.Start|ProcessStartInfo|<%@\s*Page'
$OkPorts   = @('80', '443', '25', '465', '587', '53', '389', '636', '1433', '3306', '5432', '6379', '11211')

# ---------------------------------------------------------------- helpers
function Write-Log([string]$Text) { Add-Content -LiteralPath $LogFile -Value ('{0}  {1}' -f (U (Get-Date)), $Text) -Encoding UTF8 }
function Write-Section([string]$Title) {
    Add-Content -LiteralPath $Findings -Value ("`r`n=== {0} ===" -f $Title) -Encoding UTF8
    Write-Host ">> $Title"
    Write-Log "section: $Title"
}
function Write-Note([string]$Text) { Add-Content -LiteralPath $Findings -Value ('    ' + $Text) -Encoding UTF8 }
$script:Results = New-Object System.Collections.Generic.List[object]
# Add-Flag: records a check result. Severity: CRITICAL (signs of compromise), HIGH (vulnerable+serving or exploitation
# attempts), REVIEW (analyst look, often benign), INFO (context only, never counted). Action = what to do / tell the client.
function Add-Flag {
    param([string]$Label, [string]$Slug, $Data,
          [ValidateSet('CRITICAL', 'HIGH', 'REVIEW', 'INFO')][string]$Severity = 'REVIEW', [string]$Action = '')
    $items = @($Data | Where-Object { $null -ne $_ -and "$_".Trim() -ne '' })
    if ($items.Count -eq 0) { Add-Content -LiteralPath $Findings -Value ('[   ok   ] {0}' -f $Label) -Encoding UTF8; return }
    $file = Join-Path $Ev ($Slug + '.txt')
    if ($items[0] -is [string]) {
        $items | Set-Content -LiteralPath $file -Encoding UTF8
        $preview = @($items | Select-Object -First 20)
        $sample  = @($items | Select-Object -First 3 | ForEach-Object { "$_".Trim() })
    } else {
        $items | Format-List * | Out-String -Width 4096 | Set-Content -LiteralPath $file -Encoding UTF8
        $items | Export-Csv -LiteralPath (Join-Path $Ev ($Slug + '.csv')) -NoTypeInformation -Encoding UTF8
        $preview = @(($items | Select-Object -First 20 | Format-Table -AutoSize | Out-String -Width 400) -split "`r?`n" | Where-Object { $_.Trim() })
        $sample  = @($items | Select-Object -First 3 | ForEach-Object { (@($_.PSObject.Properties | Where-Object { "$($_.Value)" -ne '' } | ForEach-Object { '{0}={1}' -f $_.Name, $_.Value }) -join '  ') })
    }
    $sample = @($sample | ForEach-Object { if ($_.Length -gt 170) { $_.Substring(0, 170) + '...' } else { $_ } })
    $script:Results.Add([pscustomobject]@{ Severity = $Severity; Check = $Slug; Finding = $Label; Count = $items.Count
                                           Action = $Action; Evidence = "evidence\$Slug.txt"; Sample = $sample })
    Add-Content -LiteralPath $Findings -Value ('[{0,-8}] {1}  ({2} items -> evidence\{3}.txt)' -f $Severity, $Label, $items.Count, $Slug) -Encoding UTF8
    if ($Action) { Add-Content -LiteralPath $Findings -Value ('           ACTION: ' + $Action) -Encoding UTF8 }
    foreach ($l in $preview) { $s = "$l"; if ($s.Length -gt 300) { $s = $s.Substring(0, 300) }; Add-Content -LiteralPath $Findings -Value ('           ' + $s) -Encoding UTF8 }
    Write-Log ('FLAG {0} [{1}]: {2} items' -f $Slug, $Severity, $items.Count)
}
# Generic host checks (tasks, services, accounts, temp files...) only count where PHP is actually serving web requests;
# elsewhere they are context only, so a workstation or non-PHP server is not reported as having "issues".
function Get-GenericSev { if ($script:PhpServing) { 'REVIEW' } else { 'INFO' } }
$script:PhpServing = $false
$UploadDirRe = '\\(uploads?|files|images?|media|cache|tmp|temp)\\'
function Get-EventData($Evt) {
    $h = @{ TimeCreated = $Evt.TimeCreated }
    try { foreach ($d in ([xml]$Evt.ToXml()).Event.EventData.Data) { $h[$d.Name] = $d.'#text' } } catch { }
    $h
}
function Get-Leaf([string]$Path) { if ($Path) { [IO.Path]::GetFileName($Path).ToLowerInvariant() } else { '' } }
function Open-SharedStream([string]$Path) {
    # Read without blocking the web server or log writer (they keep logs open)
    try { [IO.FileStream]::new($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]'ReadWrite, Delete') } catch { $null }
}
function Open-SharedReader([string]$Path) { $fs = Open-SharedStream $Path; if ($fs) { New-Object IO.StreamReader($fs) } }
function Get-SharedSha256([string]$Path) {
    $fs = Open-SharedStream $Path
    if (-not $fs) { return '' }
    try { $sha = [Security.Cryptography.SHA256]::Create(); ([BitConverter]::ToString($sha.ComputeHash($fs)) -replace '-', '').ToLowerInvariant() }
    catch { '' } finally { $fs.Dispose() }
}
# Regex search over files using shared reads (Select-String can fail on files a server holds open)
function Search-File {
    param($Files, [string]$Pattern, [string]$Exclude)
    $re = [regex]::new($Pattern, [Text.RegularExpressions.RegexOptions]::IgnoreCase)
    foreach ($f in @($Files)) {
        if (-not $f) { continue }
        $path = if ($f -is [IO.FileInfo]) { $f.FullName } else { "$f" }
        $r = Open-SharedReader $path
        if (-not $r) { Write-Log "cannot read $path"; continue }
        $n = 0
        try {
            while ($null -ne ($line = $r.ReadLine())) {
                $n++
                if ($re.IsMatch($line) -and -not ($Exclude -and $line -match $Exclude)) {
                    [pscustomobject]@{ Path = $path; LineNumber = $n; Line = $line }
                }
            }
        } finally { $r.Close() }
    }
}
function Format-Hit($h, [int]$Max = 300) { $t = $h.Line.Trim(); if ($t.Length -gt $Max) { $t = $t.Substring(0, $Max) }; '{0}:{1}: {2}' -f $h.Path, $h.LineNumber, $t }
# Copy a file into evidence\files\<Category>\<drive>\<original path>, keeping timestamps; record hashes + metadata.
function Save-Evidence {
    param([Parameter(ValueFromPipeline = $true)]$Path, [string]$Category)
    process {
        if (-not $Path) { return }
        $p = if ($Path -is [IO.FileInfo]) { $Path.FullName } else { "$Path" }
        $fi = Get-Item -LiteralPath $p -Force
        if (-not $fi -or $fi.PSIsContainer) { return }
        if (-not $script:Preserved.Add("$Category|$($fi.FullName)")) { return }
        $rec = [ordered]@{
            CollectedUtc = U (Get-Date); Category = $Category; OriginalPath = $fi.FullName; Size = $fi.Length
            CreatedUtc = U $fi.CreationTime; ModifiedUtc = U $fi.LastWriteTime; AccessedUtc = U $fi.LastAccessTime
            Owner = (Get-Acl -LiteralPath $fi.FullName).Owner; Sha256Original = (Get-SharedSha256 $fi.FullName); Sha256Copy = ''; StoredAs = ''
        }
        $over = if ($Category -eq 'logs') { ($script:LogBytes + $fi.Length) -gt ([long]$MaxLogCopyMB * 1MB) } else { $fi.Length -gt ([long]$MaxFileMB * 1MB) }
        if ($over) {
            $rec.StoredAs = 'NOT COPIED (size cap) - hashed in place'
        } else {
            $rel = ($fi.FullName -replace '^\\\\\?\\', '' -replace '^([A-Za-z]):', '$1' -replace '^\\\\', 'UNC\')
            $dst = Join-Path (Join-Path $FilesDir $Category) $rel
            try {
                [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dst))
                $in = Open-SharedStream $fi.FullName
                if (-not $in) { throw 'source not readable' }
                try { $out = [IO.File]::Create($dst); try { $in.CopyTo($out) } finally { $out.Dispose() } } finally { $in.Dispose() }
                [IO.File]::SetCreationTimeUtc($dst, $fi.CreationTimeUtc)
                [IO.File]::SetLastWriteTimeUtc($dst, $fi.LastWriteTimeUtc)
                $rec.Sha256Copy = (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash.ToLowerInvariant()
                $rec.StoredAs = 'evidence\files\' + $Category + '\' + $rel
                if (-not $rec.Sha256Copy) { $rec.StoredAs += ' (copy unreadable - removed by AV?)' }
                elseif ($rec.Sha256Copy -ne $rec.Sha256Original) { $rec.StoredAs += ' (source changed during copy - live file)' }
                if ($Category -eq 'logs') { $script:LogBytes += $fi.Length }
            } catch { $rec.StoredAs = 'COPY FAILED: ' + $_.Exception.Message }
        }
        [pscustomobject]$rec | Export-Csv -LiteralPath $CollCsv -Append -NoTypeInformation -Encoding UTF8
    }
}
function Get-IniValue([string]$Ini, [string]$Key) {
    if (-not (Test-Path -LiteralPath $Ini)) { return $null }
    $line = Select-String -LiteralPath $Ini -Pattern ('^\s*' + [regex]::Escape($Key) + '\s*=') | Select-Object -Last 1
    if (-not $line) { return $null }
    $val = ($line.Line -split '=', 2)[1].Trim()
    if ($val -match '^"([^"]*)"') { $val = $Matches[1] } else { $val = ($val -split '\s;')[0].Trim() }
    ($val -split ';')[-1].Trim()
}
function Get-Verdict([string]$Ver) {
    if ($Ver -match '^(\d+)\.(\d+)\.(\d+)') {
        $mm = '{0}.{1}' -f $Matches[1], $Matches[2]
        $patch = [int]$Matches[3]
        if (-not $Fixed.ContainsKey($mm)) { return 'EOL branch - no official fix: VULNERABLE (upgrade or isolate)' }
        if ($patch -ge $Fixed[$mm]) { return 'patched' }
        return ('VULNERABLE (fixed in {0}.{1})' -f $mm, $Fixed[$mm])
    }
    'UNKNOWN version'
}
# Version from file metadata only - never executes a discovered binary (it could be attacker-planted)
function Get-PhpVersion([string]$Path) {
    $ver = (Get-Item -LiteralPath $Path).VersionInfo.ProductVersion
    if ($ver -notmatch '^\d+\.\d+\.\d+') {
        $dll = Get-ChildItem -LiteralPath (Split-Path $Path) -Filter 'php*.dll' -File | Where-Object { $_.Name -match '^php\d+(ts)?\.dll$' } | Select-Object -First 1
        if ($dll) { $ver = $dll.VersionInfo.ProductVersion }
    }
    if ($ver -match '^(\d+\.\d+\.\d+)') { $Matches[1] } else { "$ver" }
}
function Get-WebAncestor($Proc) {
    $cur = $Proc
    for ($depth = 0; $depth -lt 5; $depth++) {
        $par = $ByPid[[int]$cur.ParentProcessId]
        if (-not $par -or $par.ProcessId -eq $cur.ProcessId) { return $null }
        if ($par.CreationDate -and $cur.CreationDate -and $par.CreationDate -gt $cur.CreationDate) { return $null }  # PID reuse
        if ($par.Name -match $WebProcRe) { return $par }
        $cur = $par
    }
    $null
}
function Save-ProcessEvidence([int]$ProcId, [string]$Reason) {
    $d = Join-Path $ProcDir $ProcId
    if (Test-Path -LiteralPath $d) { Add-Content -LiteralPath (Join-Path $d 'reason.txt') -Value $Reason; return }
    New-Item -ItemType Directory -Force -Path $d | Out-Null
    Set-Content -LiteralPath (Join-Path $d 'reason.txt') -Value $Reason
    $p = $ByPid[$ProcId]
    $p | Format-List * | Out-String -Width 4096 | Set-Content -LiteralPath (Join-Path $d 'process.txt') -Encoding UTF8
    (Get-Process -Id $ProcId).Modules | Select-Object ModuleName, FileName, FileVersion, Size |
        Export-Csv -LiteralPath (Join-Path $d 'modules.csv') -NoTypeInformation -Encoding UTF8
    Get-NetTCPConnection -OwningProcess $ProcId | Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort, State |
        Export-Csv -LiteralPath (Join-Path $d 'tcp.csv') -NoTypeInformation -Encoding UTF8
    if ($p -and $p.ExecutablePath) { Save-Evidence -Path $p.ExecutablePath -Category 'process_images' }
    Write-Log "captured process $ProcId ($Reason)"
}

'CollectedUtc,Category,OriginalPath,Size,CreatedUtc,ModifiedUtc,AccessedUtc,Owner,Sha256Original,Sha256Copy,StoredAs' |
    Set-Content -LiteralPath $CollCsv -Encoding UTF8
Write-Log ("php2shell_hunt_windows.ps1 v{0} started by {1}\{2} elevated={3} analyst='{4}' case='{5}'" -f $Version, $env:USERDOMAIN, $env:USERNAME, $isAdmin, $Analyst, $CaseId)
Write-Log ('command: {0}' -f $MyInvocation.Line)
$drv = Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='{0}'" -f $OutDir.Substring(0, 2))
Write-Log ('output: {0}   free space: {1:N1} GB' -f $OutDir, ($drv.FreeSpace / 1GB))

$Sysmon = Get-WinEvent -ListLog 'Microsoft-Windows-Sysmon/Operational'
$SysmonOn = [bool]($Sysmon -and $Sysmon.IsEnabled)
$CmdLineAudit = [bool](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit').ProcessCreationIncludeCmdLine_Enabled
$OsCaption = (Get-CimInstance Win32_OperatingSystem).Caption
$HostTz = [TimeZoneInfo]::Local.Id
@(
    "PHP2Shell hunt (CVE-2026-109618 / CVE-2026-109619) - $env:COMPUTERNAME   [script v$Version]"
    ('Case: {0}   Analyst: {1}' -f $CaseId, $Analyst)
    ('Run: {0}   Window since: {1}   OS: {2}   Host time zone: {3}' -f (U $StartUtc), (U $Since), $OsCaption, $HostTz)
    ('Telemetry: Sysmon={0}  4688-with-cmdline={1}  Elevated={2}' -f $SysmonOn, $CmdLineAudit, $isAdmin)
    'Severity: CRITICAL = signs of compromise | HIGH = vulnerable and serving, or exploitation attempts | REVIEW = analyst look, often benign | INFO = context, not counted | ok = nothing found'
    'All times written by this script are UTC (Z). IIS W3C logs are UTC; Apache/PHP logs use host local time.'
) | Set-Content -LiteralPath $Findings -Encoding UTF8

# ---------------------------------------------------------------- 0
Write-Section '0. Volatile snapshot (evidence\ only)'
$Procs = @(Get-CimInstance Win32_Process | Select-Object ProcessId, ParentProcessId, Name, ExecutablePath, CommandLine, CreationDate,
          @{ n = 'CreatedUtc'; e = { U $_.CreationDate } })
$Procs | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $Ev 'processes.csv')
$ByPid = @{}; foreach ($p in $Procs) { $ByPid[[int]$p.ProcessId] = $p }
$Tcp = @(Get-NetTCPConnection | Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort, State, OwningProcess,
        @{ n = 'Process'; e = { $ByPid[[int]$_.OwningProcess].Name } }, @{ n = 'CreatedUtc'; e = { U $_.CreationTime } })
$Tcp | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $Ev 'tcp_connections.csv')
Get-NetUDPEndpoint | Select-Object LocalAddress, LocalPort, OwningProcess, @{ n = 'Process'; e = { $ByPid[[int]$_.OwningProcess].Name } } |
    Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $Ev 'udp_endpoints.csv')
& netstat.exe -ano 2>&1 | Out-File -LiteralPath (Join-Path $SysDir 'netstat_ano.txt') -Encoding UTF8
& ipconfig.exe /all 2>&1 | Out-File -LiteralPath (Join-Path $SysDir 'ipconfig_all.txt') -Encoding UTF8
& arp.exe -a 2>&1 | Out-File -LiteralPath (Join-Path $SysDir 'arp.txt') -Encoding UTF8
Get-DnsClientCache | Select-Object Entry, RecordName, Data, TimeToLive | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $SysDir 'dns_cache.csv')
& quser.exe 2>&1 | Out-File -LiteralPath (Join-Path $SysDir 'logged_on_users.txt') -Encoding UTF8
Get-CimInstance Win32_Service | Select-Object Name, DisplayName, State, StartMode, StartName, PathName, ProcessId |
    Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $SysDir 'services.csv')
& { Get-LocalUser | Select-Object Name, Enabled, LastLogon, PasswordLastSet, SID | Format-Table -AutoSize | Out-String -Width 300
    'Administrators:'; Get-LocalGroupMember -SID 'S-1-5-32-544' | Format-Table -AutoSize | Out-String -Width 300 } |
    Set-Content -LiteralPath (Join-Path $SysDir 'local_accounts.txt') -Encoding UTF8
& { foreach ($k in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run', 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce',
                     'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run')) {
        "[$k]"; (Get-ItemProperty -LiteralPath $k | Format-List | Out-String -Width 1000).Trim(); '' } } |
    Set-Content -LiteralPath (Join-Path $SysDir 'run_keys.txt') -Encoding UTF8
Get-ScheduledTask | ForEach-Object {
    $t = $_
    foreach ($a in @($t.Actions)) {
        [pscustomobject]@{ TaskPath = $t.TaskPath; TaskName = $t.TaskName; State = "$($t.State)"; Author = $t.Author; RunAs = $t.Principal.UserId; Execute = $a.Execute; Arguments = $a.Arguments }
    }
} | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath (Join-Path $SysDir 'scheduled_tasks.csv')
Write-Note 'process list, TCP/UDP, netstat, DNS cache, sessions, services, accounts, Run keys, scheduled tasks saved.'

# Live web-descended tool processes are computed now (they are the most volatile evidence)
$Live = @(foreach ($p in ($Procs | Where-Object { $_.Name -match $ToolRe })) {
    $anc = Get-WebAncestor $p
    if ($anc) {
        [pscustomobject]@{ StartedUtc = (U $p.CreationDate); WebAncestor = ('{0} ({1})' -f $anc.Name, $anc.ProcessId)
                           Process = ('{0} ({1})' -f $p.Name, $p.ProcessId); Pid = $p.ProcessId; CommandLine = $p.CommandLine }
    }
})
foreach ($l in $Live) { Save-ProcessEvidence $l.Pid 'live child of web worker' }

if ($ProcDumpPath) {
    if (Test-Path -LiteralPath $ProcDumpPath -PathType Leaf) {
        $dumpPids = @(@($Live | ForEach-Object { [int]$_.Pid }) + @($Procs | Where-Object { $_.Name -match '^(php-cgi|php|httpd|w3wp)\.exe$' } | ForEach-Object { [int]$_.ProcessId })) |
            Select-Object -Unique | Select-Object -First $MaxDumps
        foreach ($dp in $dumpPids) {
            $dumpFile = Join-Path $MemDir ('{0}_{1}.dmp' -f $ByPid[$dp].Name, $dp)
            & $ProcDumpPath -accepteula -ma $dp $dumpFile 2>&1 | Out-File -LiteralPath (Join-Path $MemDir 'procdump.log') -Append -Encoding UTF8
            Write-Log "procdump pid $dp -> $dumpFile"
        }
        Write-Note ('memory: {0} process dump(s) in evidence\memory (procdump -ma). Highly sensitive - credentials, session data.' -f @(Get-ChildItem -LiteralPath $MemDir -Filter '*.dmp').Count)
    } else { Write-Note "memory: -ProcDumpPath '$ProcDumpPath' not found - no dumps taken." }
} else {
    Write-Note 'memory: not captured. Use -ProcDumpPath <procdump64.exe> (php-cgi / httpd / w3wp) BEFORE any recycle.'
}

# ---------------------------------------------------------------- 1
Write-Section '1. PHP runtimes'
$PhpBins = New-StringSet
foreach ($p in ($Procs | Where-Object { $_.Name -match $PhpRe -and $_.ExecutablePath })) { [void]$PhpBins.Add($p.ExecutablePath) }

$ApacheMods = @()
$ModFiles = New-StringSet
foreach ($p in ($Procs | Where-Object { $_.Name -ieq 'httpd.exe' })) {
    foreach ($m in ((Get-Process -Id $p.ProcessId).Modules | Where-Object { $_.ModuleName -match '^php\d*apache2_4\.dll$' })) {
        [void]$ModFiles.Add($m.FileName)
        $ApacheMods += [pscustomobject]@{ Pid = $p.ProcessId; Image = $m.FileName; Started = $p.CreationDate; Written = (Get-Item -LiteralPath $m.FileName).LastWriteTime }
        $cli = Join-Path (Split-Path $m.FileName) 'php.exe'
        if (Test-Path -LiteralPath $cli) { [void]$PhpBins.Add($cli) }
    }
}

$IniFiles = New-StringSet
$IisPhpBins = @()
if ($IisXml) {
    foreach ($app in @($IisXml.configuration.'system.webServer'.fastCgi.application)) {
        if (-not $app) { continue }
        $x = [Environment]::ExpandEnvironmentVariables($app.fullPath)
        if (Test-Path -LiteralPath $x) { [void]$PhpBins.Add($x); if ((Get-Leaf $x) -match $PhpRe) { $IisPhpBins += $x } }
        foreach ($ev_ in @($app.environmentVariables.environmentVariable)) {
            if ($ev_ -and $ev_.name -eq 'PHPRC') {
                $rc = [Environment]::ExpandEnvironmentVariables($ev_.value)
                foreach ($i in @($rc, (Join-Path $rc 'php.ini'))) { if (Test-Path -LiteralPath $i -PathType Leaf) { [void]$IniFiles.Add($i) } }
            }
        }
    }
}

$Common = @('C:\php*', "$env:ProgramFiles\PHP*", "${env:ProgramFiles(x86)}\PHP*", 'C:\xampp\php', 'C:\wamp*\bin\php\php*',
            'C:\laragon\bin\php\*', 'C:\tools\php*', "$env:ProgramFiles\iis express\PHP\*", "$env:ProgramFiles\Plesk\Additional\PleskPHP*",
            "${env:ProgramFiles(x86)}\Plesk\Additional\PleskPHP*")
foreach ($c in $Common) {
    Get-ChildItem -Path $c -Recurse -Depth 2 -Include 'php.exe', 'php-cgi.exe', 'php*apache2_4.dll' -File | ForEach-Object {
        if ($_.Name -like '*apache2_4.dll') { [void]$ModFiles.Add($_.FullName) } else { [void]$PhpBins.Add($_.FullName) }
    }
}
if ($DeepScan) {
    foreach ($dl in (Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3').DeviceID) {
        Get-ChildItem -Path ($dl + '\') -Recurse -Include 'php.exe', 'php-cgi.exe' -File -Force | ForEach-Object { [void]$PhpBins.Add($_.FullName) }
    }
}

# Exposure: which PHP builds are actually answering web requests right now
$ServingBins = New-StringSet
foreach ($p in ($Procs | Where-Object { $_.Name -match $PhpRe -and $_.ExecutablePath })) { [void]$ServingBins.Add($p.ExecutablePath) }
foreach ($m in $ApacheMods) { [void]$ServingBins.Add($m.Image) }
$W3svc = Get-Service -Name W3SVC
$IisRunning = [bool]($W3svc -and "$($W3svc.Status)" -eq 'Running')
if ($IisRunning) { foreach ($x in $IisPhpBins) { [void]$ServingBins.Add($x) } }
$script:PhpServing = $ServingBins.Count -gt 0

$Versions = @(foreach ($b in (@($PhpBins) + @($ModFiles) | Select-Object -Unique)) {
    $item = Get-Item -LiteralPath $b
    if (-not $item) { continue }
    $ver = Get-PhpVersion $b
    [pscustomobject]@{ Binary = $b; Version = $ver; Verdict = (Get-Verdict $ver); Serving = $ServingBins.Contains($b)
                       WrittenUtc = (U $item.LastWriteTime); Sha256 = (Get-SharedSha256 $b) }
})
$Versions | Export-Csv -LiteralPath (Join-Path $Ev 'php_versions.csv') -NoTypeInformation -Encoding UTF8
$Exposure = if ($script:PhpServing) {
    'PHP serving web requests: ' + ((@($Versions | Where-Object { $_.Serving }) | ForEach-Object { '{0} {1} ({2})' -f (Split-Path $_.Binary -Leaf), $_.Version, $_.Verdict }) -join '; ')
} elseif ($Versions.Count) { 'PHP installed but NOT serving web requests (CLI / vendor copies only)' } else { 'No PHP found' }
Write-Note ('Exposure: ' + $Exposure)
Write-Note ('{0} PHP binaries/modules found (evidence\php_versions.csv). Self-built 7.4/8.0/8.1 with the PHP team''s source backport may be fixed despite the verdict.' -f $Versions.Count)
Add-Flag 'Vulnerable PHP is serving web requests (below 8.2.35 / 8.3.36 / 8.4.27 / 8.5.12, or EOL branch)' 'php_vulnerable_serving' (
    $Versions | Where-Object { $_.Serving -and $_.Verdict -match 'VULNERABLE' } | Select-Object Binary, Version, Verdict) -Severity HIGH `
    -Action 'Client-reportable: exposed to PHP2Shell. Patch to a fixed release or isolate. Restart PHP/IIS/Apache only after this evidence is copied off.'
Add-Flag 'Vulnerable PHP installed but not serving web requests' 'php_vulnerable_idle' (
    $Versions | Where-Object { -not $_.Serving -and $_.Verdict -match 'VULNERABLE' } | Select-Object Binary, Version, Verdict) `
    -Severity $(if ($script:PhpServing) { 'REVIEW' } else { 'INFO' }) `
    -Action 'Not reachable by PHP2Shell unless wired into a web server (check it is not used by a stopped site). Update or remove at the next maintenance window.'
$UnknownVer = @($Versions | Where-Object { $_.Verdict -eq 'UNKNOWN version' })
Add-Flag 'PHP binaries whose version could not be read' 'php_unknown_version' ($UnknownVer | Select-Object Binary, Version, Serving) `
    -Severity $(if (@($UnknownVer | Where-Object { $_.Serving }).Count) { 'REVIEW' } else { 'INFO' }) -Action 'Confirm the version manually (php -v / file properties).'

$Stale = @()
foreach ($p in ($Procs | Where-Object { $_.Name -match $PhpRe -and $_.ExecutablePath })) {
    $w = (Get-Item -LiteralPath $p.ExecutablePath).LastWriteTime
    if ($p.CreationDate -and $w -gt $p.CreationDate) {
        $Stale += [pscustomobject]@{ Pid = $p.ProcessId; Image = $p.ExecutablePath; ProcessStartedUtc = (U $p.CreationDate); ImageWrittenUtc = (U $w) }
    }
}
foreach ($m in $ApacheMods) {
    if ($m.Written -gt $m.Started) { $Stale += [pscustomobject]@{ Pid = $m.Pid; Image = $m.Image; ProcessStartedUtc = (U $m.Started); ImageWrittenUtc = (U $m.Written) } }
}
Add-Flag 'PHP workers started BEFORE their binary/module was replaced - old code still in memory' 'stale_runtimes' $Stale -Severity HIGH `
    -Action 'Patched on disk but the old (likely vulnerable) build is still running. Recycle app pool / restart Apache after evidence is copied off.'

# ini-derived paths
foreach ($b in $PhpBins) { $i = Join-Path (Split-Path $b) 'php.ini'; if (Test-Path -LiteralPath $i) { [void]$IniFiles.Add($i) } }
if ($env:PHPRC) { foreach ($i in @($env:PHPRC, (Join-Path $env:PHPRC 'php.ini'))) { if (Test-Path -LiteralPath $i -PathType Leaf) { [void]$IniFiles.Add($i) } } }
$i = Join-Path $env:windir 'php.ini'; if (Test-Path -LiteralPath $i) { [void]$IniFiles.Add($i) }
$SessDirs = New-StringSet
$ErrLogs  = New-StringSet
foreach ($ini in $IniFiles) {
    $s = Get-IniValue $ini 'session.save_path'
    if ($s) { [void]$SessDirs.Add([Environment]::ExpandEnvironmentVariables($s)) }
    $e = Get-IniValue $ini 'error_log'
    if ($e -and $e -ne 'syslog') {
        $e = [Environment]::ExpandEnvironmentVariables($e)          # expand BEFORE testing (e.g. %SystemDrive%\...)
        if ([IO.Path]::IsPathRooted($e)) { [void]$ErrLogs.Add($e) }
    }
}
foreach ($d in @("$env:windir\Temp", 'C:\xampp\tmp', 'C:\wamp64\tmp', 'C:\wamp\tmp', 'C:\laragon\tmp', "$env:SystemDrive\inetpub\temp")) { [void]$SessDirs.Add($d) }
foreach ($u in (Get-ChildItem -LiteralPath "$env:SystemDrive\Users" -Directory -Force)) { [void]$SessDirs.Add((Join-Path $u.FullName 'AppData\Local\Temp')) }

# Preserve configuration needed to interpret everything else
$ConfFiles = @($IniFiles) + @($AppHost, (Join-Path $env:windir 'System32\inetsrv\config\administration.config'), (Join-Path $env:windir 'System32\inetsrv\config\redirection.config'))
foreach ($p in ($Procs | Where-Object { $_.Name -ieq 'httpd.exe' -and $_.ExecutablePath })) {
    $ConfFiles += @(Get-ChildItem -LiteralPath (Join-Path (Split-Path (Split-Path $p.ExecutablePath)) 'conf') -Recurse -Depth 2 -File -Filter '*.conf' | ForEach-Object { $_.FullName })
}
$ConfFiles += @(foreach ($r in $Roots) { Join-Path $r 'web.config'; Join-Path $r '.user.ini'; Join-Path $r '.htaccess' })
$ConfFiles | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -Unique | Save-Evidence -Category 'config'
Write-Note 'php.ini, IIS applicationHost/administration/redirection.config, Apache conf and web-root configs preserved to evidence\files\config\'

# ---------------------------------------------------------------- 2
Write-Section ('2. PHP / Apache error logs and crash events (since {0})' -f (U $Since))
$LogDirs = @('C:\xampp\apache\logs', 'C:\xampp\php\logs', 'C:\Apache24\logs', 'C:\wamp64\logs', 'C:\wamp\logs', 'C:\laragon\logs', 'C:\laragon\bin\apache\*\logs')
foreach ($p in ($Procs | Where-Object { $_.Name -ieq 'httpd.exe' -and $_.ExecutablePath })) { $LogDirs += (Join-Path (Split-Path (Split-Path $p.ExecutablePath)) 'logs') }
$ErrFiles = @(); $ApacheAcc = @()
foreach ($d in ($LogDirs | Select-Object -Unique)) {
    foreach ($f in (Get-ChildItem -Path $d -File | Where-Object { $_.Name -match '\.log' -and $_.LastWriteTime -ge $Since })) {
        if ($f.Name -match 'access') { $ApacheAcc += $f } else { $ErrFiles += $f }
    }
}
foreach ($e in $ErrLogs) { $ErrFiles += Get-ChildItem -Path ($e + '*') -File | Where-Object { $_.LastWriteTime -ge $Since } }
$ErrFiles  = @($ErrFiles | Sort-Object FullName -Unique)
$ApacheAcc = @($ApacheAcc | Sort-Object FullName -Unique)
Write-Note ('{0} error logs scanned: {1}' -f $ErrFiles.Count, (($ErrFiles | ForEach-Object { $_.FullName }) -join '; '))
if ($ErrFiles.Count) {
    Add-Flag "PHP fatal OOM 'in Unknown on line 0' (PHP2Shell exploit signature)" 'err_oom_unknown' (
        Search-File $ErrFiles '(Allowed memory size|tried to allocate).*in Unknown on line 0' | ForEach-Object { Format-Hit $_ }) -Severity HIGH `
        -Action 'Client-reportable as attempted exploitation. Match the timestamps to access logs for the source IP, then check sections 4/5/7 for success.'
    $crash = @(Search-File $ErrFiles 'AH00428|exited with status 3221225477' | ForEach-Object { Format-Hit $_ })
    Add-Flag 'Apache child crash + restart (AH00428 / 0xC0000005 access violation)' 'err_apache_child_crash' $crash `
        -Severity $(if ($crash.Count -ge 20) { 'REVIEW' } else { 'INFO' }) -Action 'Dozens+ in a short burst = ASLR brute-force pattern; a handful is normal.'
    $pre = @(Search-File $ErrFiles 'Session ID is too long or contains illegal characters|session_start\(\): Failed to (read|decode) session data|in Unknown on line 0' 'Allowed memory size|tried to allocate' |
        ForEach-Object { Format-Hit $_ })
    Add-Flag "Pre-script warnings / session anomalies ('Unknown on line 0', illegal session IDs)" 'err_prescript_session' $pre `
        -Severity $(if ($pre.Count -ge 10) { 'REVIEW' } else { 'INFO' }) -Action 'Often startup/config noise. Only matters if clustered with the OOM signature or crash bursts.'
} else {
    Write-Note 'no PHP/Apache error logs found - IIS+FastCGI only logs PHP fatals if php.ini error_log is set'
}
$WorkerCrashes = @(
    Get-WinEvent -FilterHashtable @{ LogName = 'Application'; Id = 1000; StartTime = $Since } |
    Where-Object { "$($_.Properties[0].Value)" -match $WebProcRe } |
    ForEach-Object {
        $code = $_.Properties[6].Value
        $codeTxt = if ($code -is [int] -or $code -is [uint32] -or $code -is [long]) { '0x{0:x8}' -f ([long]$code -band 0xFFFFFFFFL) } else { "$code" }
        '{0}  {1}  module={2}  code={3}' -f (U $_.TimeCreated), $_.Properties[0].Value, $_.Properties[3].Value, $codeTxt
    })
Add-Flag 'Application Error 1000: crashes of php-cgi/php/httpd/w3wp' 'evt_worker_crashes' $WorkerCrashes `
    -Severity $(if ($script:PhpServing -and $WorkerCrashes.Count -ge 5) { 'REVIEW' } else { 'INFO' }) `
    -Action 'Bursts of access-violation (0xc0000005) crashes match the brute-force pattern; occasional crashes are normal.'

# ---------------------------------------------------------------- 3
Write-Section ('3. Access logs (since {0})' -f (U $Since))
$IisLogDirs = New-StringSet
[void]$IisLogDirs.Add("$env:SystemDrive\inetpub\logs\LogFiles")
if ($IisXml) {
    $dflt = $IisXml.configuration.'system.applicationHost'.sites.siteDefaults.logFile.directory
    if ($dflt) { [void]$IisLogDirs.Add([Environment]::ExpandEnvironmentVariables($dflt)) }
    foreach ($d in @($IisXml.configuration.'system.applicationHost'.sites.site.logFile.directory)) { if ($d) { [void]$IisLogDirs.Add([Environment]::ExpandEnvironmentVariables($d)) } }
}
$IisLogs = @(foreach ($d in $IisLogDirs) { Get-ChildItem -LiteralPath $d -Recurse -File -Filter '*.log' | Where-Object { $_.LastWriteTime -ge $Since } })
$IisLogs = @($IisLogs | Sort-Object FullName -Unique)
$HttpErr = @(Get-ChildItem -LiteralPath (Join-Path $env:windir 'System32\LogFiles\HTTPERR') -File -Filter '*.log' | Where-Object { $_.LastWriteTime -ge $Since })
Write-Note ('{0} IIS logs + {1} Apache access logs in scope (IIS times are UTC)' -f $IisLogs.Count, $ApacheAcc.Count)

$AccIoc = New-Object System.Collections.Generic.List[string]
$AccUa  = New-Object System.Collections.Generic.List[string]
$AccBig = New-Object System.Collections.Generic.List[string]
$Bucket = @{}
$HaveBytes = $false
foreach ($f in $IisLogs) {
    $r = Open-SharedReader $f.FullName
    if (-not $r) { Write-Log "cannot read $($f.FullName)"; continue }
    $iIp = -1; $iUa = -1; $iM = -1; $iD = -1; $iT = -1; $iB = -1
    try {
        while ($null -ne ($line = $r.ReadLine())) {
            if ($line.StartsWith('#')) {
                if ($line.StartsWith('#Fields:')) {
                    $fl = $line.Substring(8).Trim().Split(' ')
                    $iIp = [array]::IndexOf($fl, 'c-ip'); $iUa = [array]::IndexOf($fl, 'cs(User-Agent)'); $iM = [array]::IndexOf($fl, 'cs-method')
                    $iD = [array]::IndexOf($fl, 'date'); $iT = [array]::IndexOf($fl, 'time'); $iB = [array]::IndexOf($fl, 'cs-bytes')
                    if ($iB -ge 0) { $HaveBytes = $true }
                }
                continue
            }
            if ($iIp -lt 0) { continue }
            $v = $line.Split(' ')
            if ($v.Count -le $iIp) { continue }
            $ip = $v[$iIp] -replace '^::ffff:', ''
            if ($IocSet.Contains($ip)) { $AccIoc.Add($f.FullName + ': ' + $line) }
            if ($iUa -ge 0 -and $v.Count -gt $iUa -and $v[$iUa] -match 'php2shell') { $AccUa.Add($f.FullName + ': ' + $line) }
            if ($iM -ge 0 -and $v.Count -gt $iM -and $v[$iM] -eq 'POST') {
                $n = 0L
                if ($iB -ge 0 -and $v.Count -gt $iB -and [long]::TryParse($v[$iB], [ref]$n) -and $n -ge 1000000) { $AccBig.Add($f.FullName + ': ' + $line) }
                $minute = if ($iT -ge 0 -and $v.Count -gt $iT -and $v[$iT].Length -ge 5) { $v[$iT].Substring(0, 5) } else { '' }
                $day = if ($iD -ge 0 -and $v.Count -gt $iD) { $v[$iD] } else { '' }
                $key = '{0}  {1} {2} UTC' -f $ip, $day, $minute
                $Bucket[$key] = 1 + [int]$Bucket[$key]
            }
        }
    } finally { $r.Close() }
}
# Apache common or combined format; request line may be "-" for junk/timeouts
$CombinedRe = [regex]'^(\S+) \S+ \S+ \[(\d{2}/\w{3}/\d{4}:\d{2}:\d{2})[^\]]*\] "(\S+)(?: [^"]*)?" \d{3} \S+(?: "[^"]*" "([^"]*)")?'
foreach ($f in $ApacheAcc) {
    $r = Open-SharedReader $f.FullName
    if (-not $r) { Write-Log "cannot read $($f.FullName)"; continue }
    try {
        while ($null -ne ($line = $r.ReadLine())) {
            $mt = $CombinedRe.Match($line)
            if (-not $mt.Success) { continue }
            $ip = $mt.Groups[1].Value
            if ($IocSet.Contains($ip)) { $AccIoc.Add($f.FullName + ': ' + $line) }
            if ($mt.Groups[4].Value -match 'php2shell') { $AccUa.Add($f.FullName + ': ' + $line) }
            if ($mt.Groups[3].Value -eq 'POST') {
                $key = '{0}  {1} (host local)' -f $ip, $mt.Groups[2].Value
                $Bucket[$key] = 1 + [int]$Bucket[$key]
            }
        }
    } finally { $r.Close() }
}
Add-Flag 'Requests from published PHP2Shell source IPs' 'acc_ioc_ips' $AccIoc -Severity HIGH `
    -Action 'Client-reportable as targeted. Shared anonymiser IPs: proves attempts, not compromise - check sections 4/5/7. Do not just auto-block.'
Add-Flag 'php2shell scanner user-agent (e.g. php2shell-scan/109618)' 'acc_ioc_ua' $AccUa -Severity HIGH `
    -Action 'Client-reportable as targeted by the PHP2Shell scanner. Check sections 4/5/7 for signs it succeeded.'
Add-Flag 'POSTs with request body >= 1 MB (IIS cs-bytes)' 'acc_big_posts' $AccBig -Severity REVIEW `
    -Action 'Oversized POSTs are how the exploit fills memory; legitimate file uploads also do this - check the URL and client.'
Add-Flag 'POST bursts >= 10/min from one client IP' 'acc_post_bursts' (
    $Bucket.GetEnumerator() | Where-Object { $_.Value -ge 10 } | Sort-Object Value -Descending | ForEach-Object { '{0,6}  {1}' -f $_.Value, $_.Key }) -Severity REVIEW `
    -Action 'Could be brute-forcing or just a busy form/API. Behind Cloudflare/a load balancer these are proxy IPs unless the real client IP is logged.'
if ($IisLogs.Count -and -not $HaveBytes) { Write-Note 'IIS cs-bytes is not logged (default) - enable "Bytes Received" to see oversized POSTs going forward.' }

# Preserve all in-scope logs, newest first, until the cap is reached (the rest are hashed in place)
$AllLogs = @(@($ErrFiles) + @($ApacheAcc) + @($IisLogs) + @($HttpErr) | Where-Object { $_ } | Sort-Object FullName -Unique | Sort-Object LastWriteTime -Descending)
$AllLogs | ForEach-Object { $_.FullName } | Set-Content -LiteralPath (Join-Path $Ev 'logs_in_scope.txt') -Encoding UTF8
$AllLogs | Save-Evidence -Category 'logs'
Write-Note ('{0} logs in scope; {1:N0} MB copied to evidence\files\logs (cap {2} MB) - see evidence\collected_files.csv' -f $AllLogs.Count, ($script:LogBytes / 1MB), $MaxLogCopyMB)

# ---------------------------------------------------------------- 4
Write-Section '4. PHP session files (session.upload_progress write primitive)'
$SessFiles = @(foreach ($d in $SessDirs) {
    if ((Test-Path -LiteralPath $d) -and -not ($d.TrimEnd('\') + '\').StartsWith($OutDir + '\', [StringComparison]::OrdinalIgnoreCase)) {
        Get-ChildItem -LiteralPath $d -Recurse -Depth 2 -Filter 'sess_*' -File -Force
    }
})
$SessFiles | ForEach-Object { $_.FullName } | Set-Content -LiteralPath (Join-Path $Ev 'session_files_inspected.txt') -Encoding UTF8
Write-Note ('{0} session files inspected in: {1}' -f $SessFiles.Count, (($SessDirs | Where-Object { Test-Path -LiteralPath $_ }) -join '; '))
$PoisonedSess = @(); $SessTags = @(); $SessProgress = @()
foreach ($s in $SessFiles) {
    $m = Search-File $s '<\?php|<\?=|upload_progress_' | Select-Object -First 1
    if (-not $m) { continue }
    $PoisonedSess += $s
    $snip = $m.Line
    $mm = [regex]::Match($snip, '<\?php|<\?=|upload_progress_')
    if ($snip.Length -gt 200) { $st = [Math]::Max(0, $mm.Index - 40); $snip = $snip.Substring($st, [Math]::Min(200, $snip.Length - $st)) }
    $line = '{0}  writtenUtc={1}  :: {2}' -f $s.FullName, (U $s.LastWriteTime), ($snip -replace '[^\x20-\x7E]', '.')
    if (Search-File $s '<\?php|<\?=' | Select-Object -First 1) { $SessTags += $line } else { $SessProgress += $line }
}
Add-Flag 'Session files containing PHP code (<?php / <?=)' 'session_php_code' $SessTags -Severity CRITICAL `
    -Action 'PHP2Shell write primitive used. Escalate. Files preserved in evidence\files\sessions; purge session.save_path only after the archive is verified off-host.'
Add-Flag 'Session files with leftover upload_progress_ entries (no PHP code)' 'session_upload_progress' $SessProgress -Severity REVIEW `
    -Action 'Can be legitimate upload-progress use; matters if the site has no upload-progress feature or timestamps match attack traffic.'
$PoisonedSess | Save-Evidence -Category 'sessions'

# ---------------------------------------------------------------- 5
Write-Section '5. Process lineage'
Add-Flag 'LIVE: shells / LOLBins running under php-cgi, httpd or w3wp' 'proc_live_web_children' $Live -Severity CRITICAL `
    -Action 'Escalate now. Check the command line - a few apps shell out legitimately (image/PDF tools); recon or download commands = live compromise. Do not restart; details in evidence\proc\<pid>.'

$Hist = @()
if ($SysmonOn) {
    $Hist += Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-Sysmon/Operational'; Id = 1; StartTime = $Since } | ForEach-Object {
        $d = Get-EventData $_
        if ((Get-Leaf $d.ParentImage) -match $WebProcRe -and (Get-Leaf $d.Image) -match $ToolRe) {
            [pscustomobject]@{ TimeUtc = (U $d.TimeCreated); Source = 'Sysmon1'; Parent = $d.ParentImage; Image = $d.Image; CommandLine = $d.CommandLine; User = $d.User }
        }
    }
}
$Hist += Get-WinEvent -FilterHashtable @{ LogName = 'Security'; Id = 4688; StartTime = $Since } | ForEach-Object {
    $d = Get-EventData $_
    if ((Get-Leaf $d.ParentProcessName) -match $WebProcRe -and (Get-Leaf $d.NewProcessName) -match $ToolRe) {
        [pscustomobject]@{ TimeUtc = (U $d.TimeCreated); Source = 'Sec4688'; Parent = $d.ParentProcessName; Image = $d.NewProcessName; CommandLine = $d.CommandLine; User = $d.SubjectUserName }
    }
}
Add-Flag 'HISTORY (Sysmon 1 / Security 4688): shells / LOLBins spawned by php-cgi, httpd or w3wp' 'proc_hist_web_children' ($Hist | Sort-Object TimeUtc) -Severity CRITICAL `
    -Action 'Escalate. whoami/net/certutil/powershell -enc etc. from a web worker = compromise; confirm any app that legitimately shells out.'

if ($SysmonOn) {
    $NetIoc = @(); $NetOdd = @()
    foreach ($e in (Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-Sysmon/Operational'; Id = 3; StartTime = $Since })) {
        $d = Get-EventData $e
        $line = '{0}  {1}  -> {2}:{3}  ({4})' -f (U $d.TimeCreated), $d.Image, $d.DestinationIp, $d.DestinationPort, $d.User
        if ($IocSet.Contains(("$($d.DestinationIp)" -replace '^::ffff:', ''))) { $NetIoc += $line }
        elseif ((Get-Leaf $d.Image) -match $PhpRe -and $OkPorts -notcontains "$($d.DestinationPort)") { $NetOdd += $line }
    }
    Add-Flag 'HISTORY (Sysmon 3): outbound connections to published PHP2Shell IPs' 'sysmon_net_ioc' $NetIoc -Severity CRITICAL `
        -Action 'This host connected OUT to exploitation infrastructure - escalate as probable compromise.'
    Add-Flag 'HISTORY (Sysmon 3): php/php-cgi connections on unusual ports' 'sysmon_net_php' $NetOdd -Severity REVIEW `
        -Action 'Check destinations - APIs/payment gateways on odd ports are normal; unknown hosting/VPS IPs are not.'
    $SysmonWritten = @(); $WroteExec = @(); $WroteScript = @()
    foreach ($e in (Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-Sysmon/Operational'; Id = 11; StartTime = $Since })) {
        $d = Get-EventData $e
        if ((Get-Leaf $d.Image) -match $WebProcRe -and $d.TargetFilename -match '\.(php\d?|phtml|phar|aspx?|ashx|asmx|config|exe|dll|ps1|bat|cmd|vbs|js|hta)$' -and
            $d.TargetFilename -notmatch '\\sess_|Temporary ASP\.NET Files') {
            $SysmonWritten += $d.TargetFilename
            $line = '{0}  {1}  wrote  {2}' -f (U $d.TimeCreated), $d.Image, $d.TargetFilename
            if ($d.TargetFilename -match '\.(exe|dll|ps1|bat|cmd|vbs|hta|aspx?|ashx|asmx)$' -or $d.TargetFilename -match $UploadDirRe) { $WroteExec += $line } else { $WroteScript += $line }
        }
    }
    Add-Flag 'HISTORY (Sysmon 11): web worker wrote executables/ASPX, or scripts into upload/cache folders' 'sysmon_write_exec' $WroteExec -Severity CRITICAL `
        -Action 'Dropped payload or webshell pattern - escalate. Files still present are preserved.'
    Add-Flag 'HISTORY (Sysmon 11): web worker wrote PHP/config files' 'sysmon_write_php' $WroteScript -Severity REVIEW `
        -Action 'CMS/plugin updates do this. Compare times with the client''s update/deploy activity; unexplained writes = escalate.'
    $SysmonWritten | Select-Object -Unique | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Save-Evidence -Category 'sysmon_written_files'
}

# ---------------------------------------------------------------- 6
Write-Section '6. Network (live)'
Add-Flag 'Live connections to published PHP2Shell source IPs' 'net_ioc' ($Tcp | Where-Object { $IocSet.Contains(("$($_.RemoteAddress)" -replace '^::ffff:', '')) }) -Severity HIGH `
    -Action 'Inbound to 80/443 = active attempt (client-reportable). Any other port or an outbound session = treat as compromise and escalate.'
$SusPids = @($Live | ForEach-Object { [int]$_.Pid })
Add-Flag 'Established TCP from php/php-cgi or from flagged child processes' 'net_php_outbound' -Severity REVIEW -Action 'DB/API calls are normal; unknown hosts or odd ports are not.' -Data (
    $Tcp | Where-Object { "$($_.State)" -eq 'Established' -and ($_.Process -match $PhpRe -or $SusPids -contains [int]$_.OwningProcess) -and "$($_.RemoteAddress)" -notmatch '^(127\.|::1$|::ffff:127\.)' })
Add-Flag 'Listening sockets owned by flagged child processes (bind shells)' 'net_sus_listen' -Severity CRITICAL -Action 'Bind shell pattern - escalate.' -Data (
    $Tcp | Where-Object { "$($_.State)" -eq 'Listen' -and $SusPids -contains [int]$_.OwningProcess })

# ---------------------------------------------------------------- 7
Write-Section ('7. Files changed since {0}' -f (U $Since))
Write-Note ('web roots: {0}' -f ($Roots -join '; '))
$AllWeb  = @(foreach ($r in $Roots) { Get-ChildItem -LiteralPath $r -Recurse -File -Force }) | Sort-Object FullName -Unique
$WebExt  = '\.(php\d?|phtml|phar|pht|phps|inc|aspx?|ashx|asmx|ascx|cer|asa|config)$|^(\.user\.ini|\.htaccess|php\.ini)$'
$Changed = @($AllWeb | Where-Object { $_.Name -match $WebExt -and ($_.LastWriteTime -ge $Since -or $_.CreationTime -ge $Since) } | Sort-Object LastWriteTime)
$Changed | Select-Object @{ n = 'ModifiedUtc'; e = { U $_.LastWriteTime } }, @{ n = 'CreatedUtc'; e = { U $_.CreationTime } }, Length, FullName |
    Export-Csv -LiteralPath (Join-Path $Ev 'webroot_changed.csv') -NoTypeInformation -Encoding UTF8
Write-Note ('{0} PHP/ASP.NET/config files created or changed in web roots (evidence\webroot_changed.csv) - diff against deploy history' -f $Changed.Count)
$WsHits = @(Search-File ($Changed | Where-Object { $_.Length -lt 5MB }) $ShellRe)
$WsUpl  = @($WsHits | Where-Object { $_.Path -match $UploadDirRe })
$WsCode = @($WsHits | Where-Object { $_.Path -notmatch $UploadDirRe })
Add-Flag 'Webshell functions in a NEW/CHANGED script inside an upload/cache/image folder' 'webshell_in_upload_dir' ($WsUpl | ForEach-Object { Format-Hit $_ 200 }) -Severity CRITICAL `
    -Action 'Classic dropped webshell. Escalate; do not browse to it. Copy preserved in evidence\files\webshell_candidates.'
Add-Flag 'Changed application code containing exec/eval-style functions' 'webshell_candidates' ($WsCode | ForEach-Object { Format-Hit $_ 200 }) -Severity REVIEW `
    -Action 'Frameworks and normal deployments trigger this (very noisy on dev servers). Confirm with the client/dev team the changes were theirs; look for small, obfuscated or oddly named files.'
$WsHits | ForEach-Object { $_.Path } | Select-Object -Unique | Save-Evidence -Category 'webshell_candidates'
$IniHits = @(Search-File ($Changed | Where-Object { $_.Name -match '^(\.user\.ini|\.htaccess|web\.config|php\.ini)$' }) 'auto_(prepend|append)_file|AddHandler|SetHandler|AddType.*php|<handlers|<modules|scriptProcessor')
$Prepend = @($IniHits | Where-Object { $_.Line -match 'auto_(prepend|append)_file' -and $_.Line -notmatch 'wordfence-waf\.php' -and $_.Line -notmatch '=\s*(none|"")?\s*$' })
$Handler = @($IniHits | Where-Object { $Prepend -notcontains $_ })
Add-Flag 'Changed .user.ini / .htaccess / php.ini adds auto_prepend/append_file' 'ini_prepend_persistence' ($Prepend | ForEach-Object { Format-Hit $_ }) -Severity CRITICAL `
    -Action 'Runs attacker code before every PHP request unless it is a known product. Verify the referenced file; unknown = escalate.'
Add-Flag 'Changed .htaccess / web.config handler or module directives' 'ini_handler_changes' ($Handler | ForEach-Object { Format-Hit $_ }) -Severity REVIEW `
    -Action 'Usually normal site config (most web.config files have <handlers>). Look for PHP enabled on image/upload folders or unknown modules.'
$IniHits | ForEach-Object { $_.Path } | Select-Object -Unique | Save-Evidence -Category 'ini_handler_persistence'
$UplScripts = @($AllWeb | Where-Object { $_.FullName -match $UploadDirRe -and $_.Name -match '\.(php\d?|phtml|phar|aspx?|ashx)$' -and -not ($_.Name -eq 'index.php' -and $_.Length -lt 200) })
Add-Flag 'PHP/ASPX files inside upload/cache/image folders (any age)' 'scripts_in_upload_dirs' ($UplScripts | ForEach-Object { '{0}  modifiedUtc={1}' -f $_.FullName, (U $_.LastWriteTime) }) -Severity REVIEW `
    -Action 'Upload folders should not hold scripts; some CMS caches do. Unknown or recently added ones = escalate.'
$UplScripts | Save-Evidence -Category 'scripts_in_upload_dirs'
$TmpNew = @(foreach ($t in @(@("$env:windir\Temp", 2), @("$env:ProgramData", 0), @("$env:PUBLIC", 2), @("$env:SystemDrive\PerfLogs", 2), @("$env:SystemDrive\inetpub\temp", 2))) {
    Get-ChildItem -LiteralPath $t[0] -Recurse -Depth $t[1] -File -Force |
        Where-Object { $_.CreationTime -ge $Since -and $_.Name -match '\.(exe|dll|ps1|psm1|bat|cmd|vbs|js|jse|hta|php\d?|aspx?|jsp|zip|7z|rar|dmp)$' -and
                       -not ($_.FullName + '\').StartsWith($OutDir + '\', [StringComparison]::OrdinalIgnoreCase) } |
        # validly signed installers/updaters are the main source of noise here
        Where-Object { $_.Extension -notmatch '^\.(exe|dll)$' -or (Get-AuthenticodeSignature -LiteralPath $_.FullName).Status -ne 'Valid' }
})
Add-Flag 'Unsigned scripts/binaries created since window start in Windows\Temp, ProgramData (top), Public, PerfLogs, inetpub\temp' 'tmp_new_files' (
    $TmpNew | ForEach-Object { '{0}  {1,10}  {2}' -f (U $_.CreationTime), $_.Length, $_.FullName }) -Severity (Get-GenericSev) `
    -Action 'Staging locations used after exploitation; installers also drop files here. Unknown names/scripts near attack times = escalate.'
$TmpNew | Save-Evidence -Category 'tmp_new_files'

# ---------------------------------------------------------------- 8
Write-Section '8. Persistence'
# Web identities: IIS app pools (S-1-5-82-*), IUSR (S-1-5-17)
$WebSidRe = '^S-1-5-(82-|17$)'
$AccWeb = @(); $AccNew = @(); $AccOther = @()
foreach ($e in (Get-WinEvent -FilterHashtable @{ LogName = 'Security'; Id = 4720, 4722, 4732, 4738; StartTime = $Since })) {
    $d = Get-EventData $e
    $line = '{0}  {1}  by={2}  target={3}  member={4}' -f (U $e.TimeCreated), $e.Id, $d.SubjectUserName, $d.TargetUserName, $d.MemberSid
    if ("$($d.SubjectUserSid)" -match $WebSidRe) { $AccWeb += $line } elseif ($e.Id -in 4720, 4732) { $AccNew += $line } else { $AccOther += $line }
}
Add-Flag 'Accounts created/changed BY a web identity (IIS app pool / IUSR)' 'evt_accounts_by_web' $AccWeb -Severity CRITICAL -Action 'A web process managing accounts = compromise. Escalate.'
Add-Flag 'Local accounts created or added to a local group (4720 / 4732)' 'evt_accounts' $AccNew -Severity (Get-GenericSev) -Action 'Confirm each with the client''s admins.'
Add-Flag 'Account enabled/changed (4722 / 4738 - mostly password and attribute changes)' 'evt_accounts_changed' $AccOther -Severity INFO
$TaskWeb = @(); $TaskAll = @()
foreach ($e in (Get-WinEvent -FilterHashtable @{ LogName = 'Security'; Id = 4698; StartTime = $Since })) {
    $d = Get-EventData $e; $line = '{0}  4698  {1}  by={2}' -f (U $e.TimeCreated), $d.TaskName, $d.SubjectUserName
    if ("$($d.SubjectUserSid)" -match $WebSidRe) { $TaskWeb += $line } else { $TaskAll += $line }
}
foreach ($e in (Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-TaskScheduler/Operational'; Id = 106; StartTime = $Since })) {
    $d = Get-EventData $e; $line = '{0}  106   {1}  by={2}' -f (U $e.TimeCreated), $d.TaskName, $d.UserContext
    if ("$($d.UserContext)" -match '^(IIS APPPOOL\\|.*\\IUSR$)') { $TaskWeb += $line } else { $TaskAll += $line }
}
Add-Flag 'Scheduled tasks registered BY a web identity (IIS app pool / IUSR)' 'evt_tasks_by_web' $TaskWeb -Severity CRITICAL -Action 'Web process creating persistence = compromise. Escalate.'
Add-Flag 'Scheduled tasks registered in the window (all accounts)' 'evt_tasks' $TaskAll -Severity INFO
# Built-in \Microsoft\ tasks use rundll32 etc. legitimately - only count them if they point at staging folders or PHP
Add-Flag 'Scheduled tasks running from temp/Public/PerfLogs/ProgramData, encoded PowerShell or LOLBins' 'tasks_suspicious_actions' (
    Import-Csv -LiteralPath (Join-Path $SysDir 'scheduled_tasks.csv') | ForEach-Object {
        $cmd = ('{0} {1}' -f $_.Execute, $_.Arguments)
        $staging = $cmd -match '\\(Temp|Users\\Public|PerfLogs|inetpub)\\|php(-cgi)?\.exe|powershell.*\s-e(nc|ncodedcommand)?\s'
        $lolbin  = $cmd -match '\\ProgramData\\|mshta|rundll32|regsvr32|certutil|bitsadmin'
        if ($staging -or ($lolbin -and $_.TaskPath -notlike '\Microsoft\*')) { '{0}{1}  ->  {2}' -f $_.TaskPath, $_.TaskName, $cmd }
    }) -Severity (Get-GenericSev) -Action 'Vendor updaters sometimes run from ProgramData; unknown names, encoded PowerShell or temp paths = escalate. Full list: evidence\system\scheduled_tasks.csv'
$SvcSus = @(); $SvcAll = @()
foreach ($e in (Get-WinEvent -FilterHashtable @{ LogName = 'System'; Id = 7045; StartTime = $Since })) {
    $d = Get-EventData $e; $line = '{0}  {1}  {2}  ({3})' -f (U $e.TimeCreated), $d.ServiceName, $d.ImagePath, $d.AccountName
    if ("$($d.ImagePath)" -match '\\(Temp|Users\\Public|PerfLogs|inetpub|AppData)\\|cmd(\.exe)?\s+/c|powershell|%COMSPEC%|rundll32|mshta|\\ProgramData\\[^\\]+\.exe') { $SvcSus += $line } else { $SvcAll += $line }
}
Add-Flag 'Services installed from staging folders or via cmd/PowerShell (System 7045)' 'evt_services_suspicious' $SvcSus -Severity (Get-GenericSev) `
    -Action 'Common lateral-movement / persistence pattern (PsExec-style). Confirm with the client; unknown = escalate.'
Add-Flag 'Services installed (System 7045, other)' 'evt_services' $SvcAll -Severity INFO
& { 'Filters:';   Get-CimInstance -Namespace root\subscription -ClassName __EventFilter | Format-List Name, Query | Out-String -Width 2000
    'Bindings:';  Get-CimInstance -Namespace root\subscription -ClassName __FilterToConsumerBinding | Format-List Filter, Consumer | Out-String -Width 2000 } |
    Set-Content -LiteralPath (Join-Path $SysDir 'wmi_subscriptions.txt') -Encoding UTF8
Add-Flag 'WMI event consumers (permanent subscriptions)' 'wmi_consumers' $(
    Get-CimInstance -Namespace root\subscription -ClassName CommandLineEventConsumer | Where-Object { $_.Name -ne 'BVTConsumer' } | ForEach-Object { 'CommandLine: {0} -> {1}' -f $_.Name, $_.CommandLineTemplate }
    Get-CimInstance -Namespace root\subscription -ClassName ActiveScriptEventConsumer | ForEach-Object { 'ActiveScript: {0} ({1})' -f $_.Name, $_.ScriptingEngine }
) -Severity (Get-GenericSev) -Action 'Rare in legitimate use (some management agents). Unknown consumers = escalate. Filters/bindings in evidence\system\wmi_subscriptions.txt'
if ($IisXml) {
    Add-Flag 'IIS native modules loaded from outside inetsrv / .NET framework' 'iis_foreign_modules' (
        @($IisXml.configuration.'system.webServer'.globalModules.add) |
        Where-Object { $_ -and $_.image -notmatch '\\inetsrv\\|%IIS_BIN%|\\Microsoft\.NET\\Framework(64)?\\' } |
        ForEach-Object { '{0} -> {1}' -f $_.name, $_.image }) -Severity $(if ($IisRunning) { 'REVIEW' } else { 'INFO' }) `
        -Action 'IIS backdoor technique. Monitoring/APM agents (Dynatrace, New Relic...) are legitimate; unknown DLLs = escalate.'
    $ahw = (Get-Item -LiteralPath $AppHost).LastWriteTime
    if ($ahw -ge $Since) { Write-Note ('applicationHost.config modified {0} - diff against the snapshots in %SystemDrive%\inetpub\history' -f (U $ahw)) }
}
$ThreatNames = @{}; foreach ($t in (Get-MpThreat)) { $ThreatNames[[string]$t.ThreatID] = $t.ThreatName }
$WebPathRe = (@($Roots) + @($SessDirs) + @("$env:SystemDrive\inetpub", 'C:\xampp', 'C:\wamp', 'C:\laragon') | Where-Object { $_ } |
              ForEach-Object { [regex]::Escape($_) }) -join '|'
$DefWeb = @(); $DefOther = @()
foreach ($t in (Get-MpThreatDetection | Where-Object { $_.InitialDetectionTime -ge $Since })) {
    $res = ($t.Resources -join ', ')
    $line = '{0}  {1}  {2}  via {3}' -f (U $t.InitialDetectionTime), $ThreatNames[[string]$t.ThreatID], $res, $t.ProcessName
    if ($res -match $WebPathRe -or (Get-Leaf $t.ProcessName) -match $WebProcRe) { $DefWeb += $line } else { $DefOther += $line }
}
Add-Flag 'Defender detections in web roots / session folders or by a web process' 'defender_web' $DefWeb -Severity CRITICAL `
    -Action 'Malware landed via the web stack - escalate even if Defender quarantined it (it may not be the only file).'
Add-Flag 'Defender detections elsewhere on the host' 'defender' $DefOther -Severity (Get-GenericSev) -Action 'Outside the PHP2Shell path; handle under normal AV procedure.'

# ---------------------------------------------------------------- 9
Write-Section '9. Telemetry coverage'
Write-Note ('Sysmon: {0}   4688 command lines: {1}   Security log oldest event: {2}' -f $SysmonOn, $CmdLineAudit,
    (U (Get-WinEvent -LogName Security -MaxEvents 1 -Oldest).TimeCreated))
Write-Note 'Without Sysmon/4688, section 5 only shows what is running NOW. Memory disclosure (CVE-2026-109619) leaves no host artifacts at all.'
if (-not $NoEventLogExport) {
    $q = "*[System[TimeCreated[@SystemTime>='{0}']]]" -f $Since.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.000Z')
    $exported = @()
    foreach ($ln in @('Security', 'System', 'Application', 'Windows PowerShell', 'Microsoft-Windows-PowerShell/Operational',
                      'Microsoft-Windows-Sysmon/Operational', 'Microsoft-Windows-TaskScheduler/Operational',
                      'Microsoft-Windows-Windows Defender/Operational', 'Microsoft-Windows-IIS-Configuration/Operational',
                      'Microsoft-Windows-TerminalServices-LocalSessionManager/Operational', 'Microsoft-Windows-WMI-Activity/Operational')) {
        if (-not (Get-WinEvent -ListLog $ln)) { continue }
        $file = Join-Path $EvtDir (($ln -replace '[\\/ ]', '_') + '.evtx')
        & wevtutil.exe epl $ln $file "/q:$q" 2>&1 | Out-Null
        if (Test-Path -LiteralPath $file) { $exported += $ln } else { Write-Log "event log export failed: $ln" }
    }
    Write-Note ('event logs exported for the window to evidence\eventlogs: {0}' -f ($exported -join ', '))
}

# ---------------------------------------------------------------- evidence packaging
$EndUtc = (Get-Date).ToUniversalTime()
# ---------------------------------------------------------------- verdict
$Order  = @{ CRITICAL = 0; HIGH = 1; REVIEW = 2; INFO = 3 }
$Res    = @($script:Results | Sort-Object @{ e = { $Order[$_.Severity] } }, Check)
$Counts = [ordered]@{}; foreach ($k in 'CRITICAL', 'HIGH', 'REVIEW', 'INFO') { $Counts[$k] = @($Res | Where-Object { $_.Severity -eq $k }).Count }
$HighChecks = @($Res | Where-Object { $_.Severity -eq 'HIGH' } | ForEach-Object { $_.Check })
$Reasons = @()
if ($HighChecks | Where-Object { $_ -in 'php_vulnerable_serving', 'stale_runtimes' }) { $Reasons += 'vulnerable PHP is serving web requests - patch' }
if ($HighChecks | Where-Object { $_ -in 'acc_ioc_ips', 'acc_ioc_ua', 'err_oom_unknown', 'net_ioc' }) { $Reasons += 'exploitation attempts seen (no proof of success)' }
if ($Counts.CRITICAL) {
    $Verdict = 'COMPROMISE SUSPECTED'; $ExitCode = 5; $Colour = 'Red'
    $Tell = 'YES - escalate to incident response now. Do not restart/patch until evidence is off the host.'
} elseif ($Counts.HIGH) {
    $Verdict = 'ACTION REQUIRED'; $ExitCode = 4; $Colour = 'Yellow'
    $Tell = 'YES - ' + ($Reasons -join '; ')
} elseif ($Counts.REVIEW) {
    $Verdict = 'REVIEW'; $ExitCode = 3; $Colour = 'Cyan'
    $Tell = 'NOT YET - analyst to check the REVIEW items below first (usually benign)'
} elseif ($script:PhpServing) {
    $Verdict = 'CLEAN'; $ExitCode = 0; $Colour = 'Green'
    $Tell = 'NO ACTION - patched PHP and no indicators (report as checked / clean)'
} else {
    $Verdict = 'NOT EXPOSED'; $ExitCode = 0; $Colour = 'Green'
    $Tell = 'NO ACTION - PHP is not serving web requests on this host'
}
$Confidence = if (-not $isAdmin) { 'LOW - not run elevated' }
              elseif (-not $script:PhpServing) { 'n/a - not exposed' }
              elseif (-not ($SysmonOn -or $CmdLineAudit)) { 'MEDIUM - no process history (Sysmon/4688): past shells would be missed, only live state checked' }
              else { 'GOOD' }
$Rule = '=' * 78
$Block = New-Object System.Collections.Generic.List[string]
$Block.Add($Rule)
$Block.Add((' PHP2Shell triage   {0}   {1}   v{2}' -f $env:COMPUTERNAME, (U $StartUtc), $Version))
$Block.Add((' VERDICT     : {0}' -f $Verdict))
$Block.Add((' TELL CLIENT : {0}' -f $Tell))
$Block.Add((' Exposure    : {0}' -f $Exposure))
$Block.Add((' Confidence  : {0}' -f $Confidence))
$Block.Add((' Counts      : CRITICAL {0}  HIGH {1}  REVIEW {2}   (INFO {3} - context only, not counted)' -f $Counts.CRITICAL, $Counts.HIGH, $Counts.REVIEW, $Counts.INFO))
$Block.Add($Rule)
foreach ($r in ($Res | Where-Object { $_.Severity -ne 'INFO' })) {
    $Block.Add(('[{0}] {1}  ({2})' -f $r.Severity, $r.Finding, $r.Count))
    if ($r.Action) { $Block.Add(('    -> {0}' -f $r.Action)) }
    foreach ($x in ($r.Sample | Select-Object -First 2)) { $Block.Add(('       e.g. {0}' -f $x)) }
    $Block.Add(('       full list: {0}' -f $r.Evidence))
}
$Info = @($Res | Where-Object { $_.Severity -eq 'INFO' })
if ($Info.Count) {
    $Block.Add(''); $Block.Add('Context only (not counted):')
    foreach ($r in $Info) { $Block.Add(('    [INFO] {0}  ({1}) - {2}' -f $r.Finding, $r.Count, $r.Evidence)) }
}
$Block.Add($Rule)
$body = @(Get-Content -LiteralPath $Findings -Encoding UTF8)
Set-Content -LiteralPath $Findings -Value (@($Block) + @('', 'DETAIL', '------') + $body) -Encoding UTF8
$SummaryObj = [ordered]@{
    Host = $env:COMPUTERNAME; OS = $OsCaption; RunUtc = (U $StartUtc); SinceUtc = (U $Since); ScriptVersion = $Version
    CaseId = $CaseId; Analyst = $Analyst; Verdict = $Verdict; TellClient = $Tell; Exposure = $Exposure; Confidence = $Confidence
    ExitCode = $ExitCode; Counts = $Counts
    PhpVersions = @($Versions | Select-Object Binary, Version, Verdict, Serving)
    Findings = @($Res | Select-Object Severity, Check, Finding, Count, Action, Sample)
    Archive = ''; ArchiveSha256 = ''
}
$SummaryJson = Join-Path $OutDir 'summary.json'
[IO.File]::WriteAllText($SummaryJson, ($SummaryObj | ConvertTo-Json -Depth 6), $Utf8NoBom)
@($Error | Select-Object -First 1000 | ForEach-Object { "$($_.InvocationInfo.MyCommand): $($_.Exception.Message)" }) |
    Set-Content -LiteralPath (Join-Path $OutDir 'collection_errors.txt') -Encoding UTF8
$ScriptSha = if ($PSCommandPath) { (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant() } else { 'n/a' }
$Zip = $OutDir + '.zip'
$nPreserved = @(Import-Csv -LiteralPath $CollCsv).Count
@(
    'CHAIN OF CUSTODY / COLLECTION RECORD'
    '====================================='
    ('Case reference      : {0}' -f $CaseId)
    ('Analyst             : {0}' -f $Analyst)
    ('Executed as         : {0}\{1} (SID {2}), elevated={3}' -f $env:USERDOMAIN, $env:USERNAME, $MySid, $isAdmin)
    ('Host                : {0}  (domain: {1})' -f $env:COMPUTERNAME, (Get-CimInstance Win32_ComputerSystem).Domain)
    ('Host IPs            : {0}' -f ((Get-NetIPAddress | Where-Object { $_.IPAddress -notmatch '^(127\.|::1|fe80)' } | ForEach-Object { $_.IPAddress }) -join ', '))
    ('OS                  : {0} build {1}' -f $OsCaption, [Environment]::OSVersion.Version)
    ('Host time zone      : {0}' -f $HostTz)
    ('Collection start    : {0}   [host local: {1}]' -f (U $StartUtc), $StartUtc.ToLocalTime().ToString('yyyy-MM-dd HH:mm:ss zzz'))
    ('Collection end      : {0}' -f (U $EndUtc))
    ('Hunt window since   : {0}' -f (U $Since))
    ('Tool                : php2shell_hunt_windows.ps1 v{0}  sha256={1}' -f $Version, $ScriptSha)
    ('Options             : MaxLogCopyMB={0} MaxFileMB={1} EventLogExport={2} ProcDump={3} DeepScan={4}' -f $MaxLogCopyMB, $MaxFileMB, (-not $NoEventLogExport), [bool]$ProcDumpPath, [bool]$DeepScan)
    ('Output folder       : {0}' -f $OutDir)
    ('Files preserved     : {0} entries in evidence\collected_files.csv' -f $nPreserved)
    ('Verdict at capture  : {0}  (CRITICAL {1} / HIGH {2} / REVIEW {3})' -f $Verdict, $Counts.CRITICAL, $Counts.HIGH, $Counts.REVIEW)
    'Integrity           : every file listed in SHA256SUMS (verify: .\php2shell_hunt_windows.ps1 -VerifyPath <folder>  or  sha256sum -c SHA256SUMS)'
    ('Archive             : {0}  (hash in {0}.sha256)' -f $Zip)
    ''
    'Handling notes: evidence contains live session tokens, credentials in configs/environment, and possibly'
    'live webshells/malware. Store encrypted, restrict access, do not open copied files in a browser or PHP.'
    'AV/EDR may quarantine copied webshells: if SHA256SUMS verification reports a MISSING file, check AV history.'
    ''
    'TRANSFER LOG (complete by hand for each hand-off)'
    'Date/time (UTC) | Released by | Received by | Purpose / location | Archive SHA256 verified (Y/N)'
    '----------------+-------------+-------------+--------------------+------------------------------'
) | Set-Content -LiteralPath (Join-Path $OutDir 'chain_of_custody.txt') -Encoding UTF8
Write-Log 'collection finished; building manifest'

$base = $OutDir + '\'
$sumLines = @(Get-ChildItem -LiteralPath $OutDir -Recurse -File -Force | Where-Object { $_.FullName -ne (Join-Path $OutDir 'SHA256SUMS') } | Sort-Object FullName | ForEach-Object {
    $h = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
    if (-not $h) { $h = 'UNREADABLE' }
    '{0} *{1}' -f $h.ToLowerInvariant(), ($_.FullName.Substring($base.Length) -replace '\\', '/')
})
[IO.File]::WriteAllLines((Join-Path $OutDir 'SHA256SUMS'), [string[]]$sumLines, $Utf8NoBom)

try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::CreateFromDirectory($OutDir, $Zip, [IO.Compression.CompressionLevel]::Optimal, $true)
    $ZipSha = (Get-FileHash -LiteralPath $Zip -Algorithm SHA256).Hash.ToLowerInvariant()
    [IO.File]::WriteAllText($Zip + '.sha256', ('{0} *{1}' -f $ZipSha, (Split-Path $Zip -Leaf)) + "`n", $Utf8NoBom)
    foreach ($z in @($Zip, ($Zip + '.sha256'))) { & icacls.exe $z @FileAclArgs | Out-Null }
    $ArchMsg = 'Archive: {0}  sha256={1}' -f $Zip, $ZipSha
} catch {
    $ArchMsg = 'Archive FAILED ({0}) - evidence left in {1}; archive manually' -f $_.Exception.Message, $OutDir
}
# Sidecar summary next to the archive (with the archive hash) - safe to share, holds no evidence content
$SummaryObj.Archive = $Zip; $SummaryObj.ArchiveSha256 = "$ZipSha"
$SideJson = $OutDir + '.summary.json'
[IO.File]::WriteAllText($SideJson, ($SummaryObj | ConvertTo-Json -Depth 6), $Utf8NoBom)
$CsvRow = [pscustomobject]@{
    Host = $env:COMPUTERNAME; RunUtc = (U $StartUtc); Verdict = $Verdict; TellClient = $Tell
    Critical = $Counts.CRITICAL; High = $Counts.HIGH; Review = $Counts.REVIEW; Info = $Counts.INFO
    Exposure = $Exposure; Confidence = $Confidence
    Findings = (@($Res | Where-Object { $_.Severity -ne 'INFO' } | ForEach-Object { '[{0}] {1}' -f $_.Severity, $_.Finding }) -join ' | ')
    Archive = $Zip; ArchiveSha256 = "$ZipSha"; CaseId = $CaseId
}
$SideCsv = $OutDir + '.summary.csv'
$CsvRow | Export-Csv -LiteralPath $SideCsv -NoTypeInformation -Encoding UTF8
$ShareMsg = ''
if ($ResultShare) {
    try {
        if (-not (Test-Path -LiteralPath $ResultShare)) { New-Item -ItemType Directory -Path $ResultShare -Force -ErrorAction Stop | Out-Null }
        $leaf = Split-Path $OutDir -Leaf
        Copy-Item -LiteralPath $SideJson -Destination (Join-Path $ResultShare ($leaf + '.summary.json')) -Force -ErrorAction Stop
        Copy-Item -LiteralPath $SideCsv  -Destination (Join-Path $ResultShare ($leaf + '.summary.csv'))  -Force -ErrorAction Stop
        $ShareMsg = "Result copied to $ResultShare"
        if ($CopyEvidenceToShare -and $ZipSha) {
            $dz = Join-Path $ResultShare (Split-Path $Zip -Leaf)
            Copy-Item -LiteralPath $Zip -Destination $dz -Force -ErrorAction Stop
            Copy-Item -LiteralPath ($Zip + '.sha256') -Destination ($dz + '.sha256') -Force -ErrorAction Stop
            $remote = (Get-FileHash -LiteralPath $dz -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($remote -eq $ZipSha) { $ShareMsg += '; evidence archive copied and hash VERIFIED' ; Write-Log "archive copied to $dz, hash verified" }
            else { $ShareMsg += '; evidence archive copy hash MISMATCH - do not delete local copy'; Write-Log "archive copy hash mismatch at $dz" }
        }
    } catch { $ShareMsg = 'Copy to result share FAILED: ' + $_.Exception.Message }
}

Write-Host ''
foreach ($l in $Block) {
    $c = if ($l -like ' VERDICT*' -or $l -like ' TELL CLIENT*') { $Colour }
         elseif ($l -like '`[CRITICAL`]*') { 'Red' } elseif ($l -like '`[HIGH`]*') { 'Yellow' } elseif ($l -like '`[REVIEW`]*') { 'Cyan' }
         elseif ($l -like '    `[INFO`]*' -or $l -like '       *') { 'DarkGray' } else { 'Gray' }
    Write-Host $l -ForegroundColor $c
}
Write-Host ('Report : {0}' -f $Findings)
Write-Host $ArchMsg
Write-Host ('Summary: {0}' -f $SideJson)
if ($ShareMsg) { Write-Host $ShareMsg }
Write-Host 'Record the archive SHA256 in the case ticket, copy the .zip + .sha256 off the host, verify, then'
Write-Host ('remove {0} and the .zip from this host (the copy contains sensitive data).' -f $OutDir)
Write-Host ('Exit code {0}  (0 clean/not exposed, 3 review, 4 action required, 5 compromise suspected)' -f $ExitCode)
exit $ExitCode
